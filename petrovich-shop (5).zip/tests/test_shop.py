"""Shop & cart tests."""
import pytest
from decimal import Decimal
from app.extensions import db
from app.models.user import User, Role
from app.models.product import Product
from app.models.order import Order, OrderStatus, DeliveryMethod, OrderItem


class TestCatalog:
    def test_catalog_loads(self, client):
        r = client.get("/catalog")
        assert r.status_code == 200
        assert b"\xd0\x9a\xd0\xb0\xd1\x82\xd0\xb0\xd0\xbb\xd0\xbe\xd0\xb3" in r.data  # "Каталог"

    def test_catalog_filter_by_category(self, client, app):
        r = client.get("/catalog?category=fruktovyi")
        assert r.status_code == 200

    def test_catalog_search(self, client):
        r = client.get("/catalog?q=marmelad")
        assert r.status_code == 200

    def test_catalog_sort_price_asc(self, client):
        r = client.get("/catalog?sort=price_asc")
        assert r.status_code == 200


class TestProductDetail:
    def test_product_detail_loads(self, client, app):
        with app.app_context():
            p = Product.query.first()
            slug = p.slug
        r = client.get(f"/product/{slug}")
        assert r.status_code == 200

    def test_product_detail_404(self, client):
        r = client.get("/product/non-existent-slug-xyz")
        assert r.status_code == 404


class TestCart:
    def test_cart_empty_state(self, client):
        r = client.get("/cart")
        assert r.status_code == 200

    def test_cart_add(self, client, app):
        with app.app_context():
            p = Product.query.first()
            pid = p.id
        r = client.post("/cart/add", data={"product_id": pid, "qty": 2},
                        headers={"X-Requested-With": "XMLHttpRequest"})
        assert r.status_code == 200
        import json
        data = json.loads(r.data)
        assert data["ok"] is True
        assert data["cart_count"] == 2

    def test_cart_add_out_of_stock_rejected(self, client, app):
        with app.app_context():
            p = Product.query.first()
            p.stock = 0
            db.session.commit()
            pid = p.id
        r = client.post("/cart/add", data={"product_id": pid, "qty": 1},
                        headers={"X-Requested-With": "XMLHttpRequest"})
        # Should be 400 with error
        assert r.status_code == 400

    def test_cart_update_qty(self, client, app):
        with app.app_context():
            p = Product.query.first()
            pid = p.id
        client.post("/cart/add", data={"product_id": pid, "qty": 1},
                    headers={"X-Requested-With": "XMLHttpRequest"})
        r = client.post("/cart/update", data={"product_id": pid, "qty": 5},
                        headers={"X-Requested-With": "XMLHttpRequest"})
        assert r.status_code == 200
        import json
        data = json.loads(r.data)
        assert data["qty"] == 5

    def test_cart_remove(self, client, app):
        with app.app_context():
            p = Product.query.first()
            pid = p.id
        client.post("/cart/add", data={"product_id": pid, "qty": 1},
                    headers={"X-Requested-With": "XMLHttpRequest"})
        r = client.post("/cart/remove", data={"product_id": pid},
                        headers={"X-Requested-With": "XMLHttpRequest"})
        assert r.status_code == 200
        import json
        data = json.loads(r.data)
        assert data["cart_count"] == 0

    def test_cart_clear(self, client, app):
        with app.app_context():
            p = Product.query.first()
            pid = p.id
        client.post("/cart/add", data={"product_id": pid, "qty": 3},
                    headers={"X-Requested-With": "XMLHttpRequest"})
        r = client.post("/cart/clear", headers={"X-Requested-With": "XMLHttpRequest"})
        assert r.status_code == 200


class TestCheckout:
    def test_checkout_public_empty_cart_redirects(self, client):
        """Checkout is public now (guest orders allowed); empty cart redirects to catalog."""
        r = client.get("/checkout", follow_redirects=False)
        assert r.status_code == 302

    def test_checkout_empty_cart_redirects_logged_in(self, client, login_user):
        r = client.get("/checkout", follow_redirects=True)
        assert r.status_code == 200

    def test_checkout_creates_order(self, client, app, login_user):
        with app.app_context():
            p = Product.query.first()
            pid = p.id
            initial_stock = p.stock
        client.post("/cart/add", data={"product_id": pid, "qty": 2},
                    headers={"X-Requested-With": "XMLHttpRequest"})

        r = client.post("/checkout", data={
            "contact_name": "Иван Тестов",
            "contact_phone": "+7 900 123-45-67",
            "contact_email": "user@test.com",
            "delivery_method": "pickup",
            "address": "",
            "comment": "тестовый заказ",
        }, follow_redirects=True)
        assert r.status_code == 200

        with app.app_context():
            # Verify order was created
            orders = Order.query.all()
            assert len(orders) == 1
            o = orders[0]
            assert o.status == OrderStatus.NEW
            assert o.delivery_method == DeliveryMethod.PICKUP
            # Verify stock was decremented
            p2 = db.session.get(Product, pid)
            assert p2.stock == initial_stock - 2

    def test_checkout_server_recalculates_price(self, client, app, login_user):
        """Even if client tampers with form, server uses DB prices."""
        with app.app_context():
            p = Product.query.first()
            pid = p.id
            real_price = float(p.price)
        client.post("/cart/add", data={"product_id": pid, "qty": 3},
                    headers={"X-Requested-With": "XMLHttpRequest"})
        # Submit checkout — server should compute order.total from DB
        r = client.post("/checkout", data={
            "contact_name": "Хакер",
            "contact_phone": "+7 900 000-00-00",
            "delivery_method": "pickup",
        }, follow_redirects=True)
        assert r.status_code == 200
        with app.app_context():
            o = Order.query.first()
            assert float(o.total) == real_price * 3

    def test_checkout_insufficient_stock(self, client, app, login_user):
        with app.app_context():
            p = Product.query.first()
            pid = p.id
            p.stock = 1
            db.session.commit()
        client.post("/cart/add", data={"product_id": pid, "qty": 5},
                    headers={"X-Requested-With": "XMLHttpRequest"})
        # Cart has 5 items but stock is only 1 — checkout should fail
        r = client.post("/checkout", data={
            "contact_name": "Тест",
            "contact_phone": "+7 900 000-00-00",
            "delivery_method": "pickup",
        }, follow_redirects=True)
        assert r.status_code == 200
        # No order created
        with app.app_context():
            assert Order.query.count() == 0

    def test_guest_checkout_creates_order(self, client, app):
        """Guest (not logged in) can place an order."""
        with app.app_context():
            p = Product.query.first()
            pid = p.id
            stock_before = p.stock
        client.post("/cart/add", data={"product_id": pid, "qty": 1},
                    headers={"X-Requested-With": "XMLHttpRequest"})
        r = client.post("/checkout", data={
            "contact_name": "Гость Тестов",
            "contact_phone": "+7 900 111-22-33",
            "contact_email": "guest@test.com",
            "delivery_method": "courier",
            "address": "ул. Ленина, 1",
            "comment": "гостевой заказ",
        }, follow_redirects=True)
        assert r.status_code == 200
        with app.app_context():
            o = Order.query.first()
            assert o is not None
            assert o.user_id is None
            assert o.contact_name == "Гость Тестов"
            assert o.delivery_method == DeliveryMethod.COURIER
            assert float(o.delivery_cost) == 25.0
            # Stock decremented
            p2 = db.session.get(Product, pid)
            assert p2.stock == stock_before - 1

    def test_courier_delivery_costs_25(self, client, app, login_user):
        with app.app_context():
            p = Product.query.first()
            pid = p.id
            price = float(p.price)
        client.post("/cart/add", data={"product_id": pid, "qty": 2},
                    headers={"X-Requested-With": "XMLHttpRequest"})
        client.post("/checkout", data={
            "contact_name": "Тест",
            "contact_phone": "+7 900 000-00-00",
            "delivery_method": "courier",
            "address": "пр. Металлургов 5",
        }, follow_redirects=True)
        with app.app_context():
            o = Order.query.first()
            assert float(o.total) == price * 2 + 25

    def test_courier_without_address_rejected(self, client, app, login_user):
        with app.app_context():
            p = Product.query.first()
            pid = p.id
        client.post("/cart/add", data={"product_id": pid, "qty": 1},
                    headers={"X-Requested-With": "XMLHttpRequest"})
        client.post("/checkout", data={
            "contact_name": "Тест",
            "contact_phone": "+7 900 000-00-00",
            "delivery_method": "courier",
            "address": "",
        }, follow_redirects=True)
        with app.app_context():
            assert Order.query.count() == 0

    def test_unknown_delivery_method_rejected(self, client, app, login_user):
        with app.app_context():
            p = Product.query.first()
            pid = p.id
        client.post("/cart/add", data={"product_id": pid, "qty": 1},
                    headers={"X-Requested-With": "XMLHttpRequest"})
        client.post("/checkout", data={
            "contact_name": "Тест",
            "contact_phone": "+7 900 000-00-00",
            "delivery_method": "post",
        }, follow_redirects=True)
        with app.app_context():
            assert Order.query.count() == 0


class TestAdminOrders:
    def test_admin_can_change_status(self, client, app, login_admin):
        """Admin updates order status via admin panel."""
        with app.app_context():
            prod = Product.query.first()
            user = User.query.filter_by(role=Role.CUSTOMER).first()
            if not user:
                user = User(name="X", email="x@x.local", role=Role.CUSTOMER, email_confirmed=True, is_active_user=True)
                user.set_password("Password123")
                db.session.add(user); db.session.flush()
            order = Order(
                number="PETR-TEST-001", user_id=user.id,
                contact_name="X", contact_phone="+79000000000",
                delivery_method=DeliveryMethod.PICKUP, status=OrderStatus.NEW,
                items_total=prod.price, total=prod.price,
            )
            db.session.add(order); db.session.flush()
            item = OrderItem(order_id=order.id, product_id=prod.id,
                             product_name=prod.name, product_price=prod.price,
                             quantity=1, line_total=prod.price)
            db.session.add(item)
            db.session.commit()
            oid = order.id

        r = client.post(f"/admin/orders/{oid}", data={
            "status": "confirmed",
            "admin_comment": "ok",
        }, follow_redirects=True)
        assert r.status_code == 200
        with app.app_context():
            o = db.session.get(Order, oid)
            assert o.status == OrderStatus.CONFIRMED

    def test_cancel_restores_stock(self, client, app, login_admin):
        with app.app_context():
            user = User.query.filter_by(role=Role.CUSTOMER).first()
            if not user:
                user = User(name="X", email="x@x.local", role=Role.CUSTOMER, email_confirmed=True, is_active_user=True)
                user.set_password("Password123")
                db.session.add(user); db.session.flush()
            prod = Product.query.first()
            stock_before = prod.stock
            order = Order(
                number="PETR-CANCEL-1", user_id=user.id,
                contact_name="X", contact_phone="+79000000000",
                delivery_method=DeliveryMethod.PICKUP, status=OrderStatus.NEW,
                items_total=prod.price * 2, total=prod.price * 2,
            )
            db.session.add(order); db.session.flush()
            item = OrderItem(order_id=order.id, product_id=prod.id,
                             product_name=prod.name, product_price=prod.price,
                             quantity=2, line_total=prod.price * 2)
            db.session.add(item)
            prod.stock -= 2
            db.session.commit()
            oid = order.id
            pid = prod.id

        r = client.post(f"/admin/orders/{oid}/cancel", follow_redirects=True)
        assert r.status_code == 200
        with app.app_context():
            o = db.session.get(Order, oid)
            assert o.status == OrderStatus.CANCELLED
            p2 = db.session.get(Product, pid)
            assert p2.stock == stock_before  # restored
