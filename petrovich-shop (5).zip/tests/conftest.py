"""Pytest configuration and fixtures."""
import os
import sys
import pytest
import tempfile
import shutil

# Ensure project root is on path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app import create_app
from app.extensions import db as _db
from app.models.user import User, Role
from app.models.product import Product, Category, Flavor
from app.models.settings import ShopSettings


@pytest.fixture(scope="function")
def app():
    """Create app for testing with in-memory SQLite."""
    # Use a fresh temp dir
    db_fd, db_path = tempfile.mkstemp(suffix=".db")
    os.environ["SECRET_KEY"] = "test-secret-key-for-pytest-only-0123456789"
    os.environ["DATABASE_URL"] = f"sqlite:///{db_path}"
    os.environ["MAIL_SUPPRESS_SEND"] = "true"
    os.environ["RATELIMIT_ENABLED"] = "false"
    os.environ["WTF_CSRF_ENABLED"] = "false"

    app = create_app("testing")
    with app.app_context():
        _db.create_all()
        # Seed shop settings
        ShopSettings.get()
        # Seed a category + flavor + product
        cat = Category(name="Фруктовый", slug="fruktovyi", description="Фруктовый", is_active=True)
        _db.session.add(cat)
        _db.session.flush()
        flav = Flavor(name="Апельсин", slug="apelsin", description="Цитрус", color_hex="#FF6F00")
        _db.session.add(flav)
        _db.session.flush()
        prod = Product(
            name="Апельсиновый мармелад",
            slug="apelsinovyi-marmelad-1",
            description="Яркий",
            composition="Агар, сахар, апельсин",
            taste="Цитрус",
            weight_g=250,
            price=480,
            shelf_life_days=10,
            stock=10,
            is_published=True,
            is_popular=True,
            is_new=False,
            category_id=cat.id,
        )
        prod.flavors.append(flav)
        _db.session.add(prod)
        _db.session.commit()
        yield app
        _db.session.remove()
        _db.drop_all()
    os.close(db_fd)
    os.unlink(db_path)


@pytest.fixture(scope="function")
def db(app):
    return _db


@pytest.fixture(scope="function")
def client(app):
    return app.test_client()


@pytest.fixture(scope="function")
def runner(app):
    return app.test_cli_runner()


@pytest.fixture
def make_user(app):
    from werkzeug.security import generate_password_hash
    def _make(email="user@test.com", password="Password123", name="Тест", role=Role.CUSTOMER):
        with app.app_context():
            u = User(name=name, email=email, role=role, email_confirmed=True, is_active_user=True)
            u.set_password(password)
            _db.session.add(u)
            _db.session.commit()
            return u.id
    return _make


@pytest.fixture
def login_user(client, make_user):
    """Log in a regular user; returns user id."""
    uid = make_user()
    with client.session_transaction() as sess:
        sess["_user_id"] = str(uid)
        sess["_fresh"] = True
    return uid


@pytest.fixture
def make_admin(app):
    def _make(email="admin@test.com", password="AdminPassword123"):
        with app.app_context():
            u = User(name="Админ", email=email, role=Role.ADMIN, email_confirmed=True, is_active_user=True)
            u.set_password(password)
            _db.session.add(u)
            _db.session.commit()
            return u.id
    return _make


@pytest.fixture
def login_admin(client, make_admin):
    uid = make_admin()
    with client.session_transaction() as sess:
        sess["_user_id"] = str(uid)
        sess["_fresh"] = True
    return uid
