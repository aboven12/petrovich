"""Auth & security tests."""
import pytest
from app.models.user import User, Role
from app.extensions import db


class TestRegistration:
    def test_register_get(self, client):
        r = client.get("/auth/register")
        assert r.status_code == 200
        assert b"\xd0\xa0\xd0\xb5\xd0\xb3\xd0\xb8\xd1\x81\xd1\x82\xd1\x80" in r.data  # "Регистр"

    def test_register_success(self, client, app):
        r = client.post("/auth/register", data={
            "name": "Тест Тестов",
            "email": "new@test.com",
            "password": "SuperPass123",
            "confirm": "SuperPass123",
            "agree": "y",
        }, follow_redirects=True)
        assert r.status_code == 200
        with app.app_context():
            u = User.query.filter_by(email="new@test.com").first()
            assert u is not None
            assert u.role == Role.CUSTOMER
            assert u.email_confirmed is False
            assert u.password_hash != "SuperPass123"  # not plain

    def test_register_duplicate_email_rejected(self, client, make_user):
        make_user(email="dup@test.com")
        r = client.post("/auth/register", data={
            "name": "Другой",
            "email": "DUP@test.com",  # case-insensitive
            "password": "SuperPass123",
            "confirm": "SuperPass123",
            "agree": "y",
        })
        # Form validation error stays on the page
        assert r.status_code == 200
        assert b"already" in r.data or b"\xd1\x83\xd0\xb6\xd0\xb5" in r.data  # already / уже

    def test_register_password_mismatch(self, client):
        r = client.post("/auth/register", data={
            "name": "Тест",
            "email": "x@test.com",
            "password": "SuperPass123",
            "confirm": "Different123",
            "agree": "y",
        })
        assert r.status_code == 200

    def test_register_short_password_rejected(self, client, app):
        r = client.post("/auth/register", data={
            "name": "Тест",
            "email": "x@test.com",
            "password": "1234567",  # 7 chars — below minimum of 8
            "confirm": "1234567",
            "agree": "y",
        })
        assert r.status_code == 200  # form re-rendered with errors
        # Ensure user was NOT created
        with app.app_context():
            from app.models.user import User
            u = User.query.filter_by(email="x@test.com").first()
            assert u is None


class TestLogin:
    def test_login_success(self, client, app):
        make = app.test_cli_runner()
        # create user via direct DB
        with app.app_context():
            from app.models.user import User
            u = User(name="Тест", email="login@test.com", role=Role.CUSTOMER, email_confirmed=True, is_active_user=True)
            u.set_password("Password123")
            db.session.add(u)
            db.session.commit()
        r = client.post("/auth/login", data={
            "email": "login@test.com",
            "password": "Password123",
            "remember": "y",
        }, follow_redirects=True)
        assert r.status_code == 200

    def test_login_wrong_password(self, client, app):
        with app.app_context():
            from app.models.user import User
            u = User(name="Тест", email="wrong@test.com", role=Role.CUSTOMER, email_confirmed=True, is_active_user=True)
            u.set_password("Password123")
            db.session.add(u)
            db.session.commit()
        r = client.post("/auth/login", data={
            "email": "wrong@test.com",
            "password": "WrongPassword999",
        })
        assert r.status_code == 200
        assert b"\xd0\x9d\xd0\xb5\xd0\xb2\xd0\xb5\xd1\x80" in r.data  # "Невер"

    def test_login_nonexistent_user(self, client):
        r = client.post("/auth/login", data={
            "email": "nobody@test.com",
            "password": "Password123",
        })
        assert r.status_code == 200
        assert b"\xd0\x9d\xd0\xb5\xd0\xb2\xd0\xb5\xd1\x80" in r.data

    def test_login_blocked_account(self, client, app):
        with app.app_context():
            from app.models.user import User
            u = User(name="Блок", email="blocked@test.com", role=Role.CUSTOMER, email_confirmed=True, is_active_user=False)
            u.set_password("Password123")
            db.session.add(u)
            db.session.commit()
        r = client.post("/auth/login", data={
            "email": "blocked@test.com",
            "password": "Password123",
        })
        assert r.status_code == 200


class TestLogout:
    def test_logout_requires_login(self, client):
        r = client.get("/auth/logout")
        assert r.status_code == 302  # redirect to login

    def test_logout_success(self, client, login_user):
        r = client.get("/auth/logout", follow_redirects=True)
        assert r.status_code == 200


class TestSecurity:
    def test_admin_route_forbidden_for_customer(self, client, login_user):
        r = client.get("/admin/")
        assert r.status_code == 403

    def test_admin_route_forbidden_for_anonymous(self, client):
        r = client.get("/admin/")
        assert r.status_code == 403 or r.status_code == 302  # might redirect to login

    def test_admin_route_ok_for_admin(self, client, login_admin):
        r = client.get("/admin/")
        assert r.status_code == 200

    def test_password_not_in_db_plaintext(self, app, make_user):
        uid = make_user(password="MyPassword123")
        with app.app_context():
            u = db.session.get(User, uid)
            assert u.password_hash != "MyPassword123"
            assert "MyPassword123" not in u.password_hash

    def test_user_cannot_view_other_order(self, client, app, make_user):
        """IDOR: user A cannot view order of user B."""
        from app.models.order import Order, OrderStatus, DeliveryMethod
        # create user B
        uid_b = make_user(email="b@test.com")
        with app.app_context():
            from app.models.user import User
            from app.models.product import Product
            user_b = db.session.get(User, uid_b)
            prod = Product.query.first()
            order = Order(
                number="PETR-X-001",
                user_id=uid_b,
                contact_name="B",
                contact_phone="+79001234567",
                delivery_method=DeliveryMethod.PICKUP,
                status=OrderStatus.NEW,
                items_total=prod.price,
                total=prod.price,
            )
            db.session.add(order)
            db.session.commit()
            oid = order.id
        # Login as user A
        uid_a = make_user(email="a@test.com")
        with client.session_transaction() as sess:
            sess["_user_id"] = str(uid_a)
            sess["_fresh"] = True
        r = client.get(f"/account/orders/{oid}")
        assert r.status_code == 403

    def test_csrf_protection_in_production(self):
        """Production config keeps CSRF enabled and Secure cookies."""
        from config import ProductionConfig
        assert ProductionConfig.WTF_CSRF_ENABLED is True
        assert ProductionConfig.SESSION_COOKIE_SECURE is True

    def test_xss_in_review_text_is_escaped(self, client, app, login_user):
        """Submit a review with script tag, ensure it's escaped on render."""
        # First need a product; use seeded one
        with app.app_context():
            from app.models.product import Product
            prod = Product.query.first()
            pid = prod.id
            slug = prod.slug
        r = client.post("/account/reviews", data={
            "product_id": pid,
            "rating": "5",
            "text": "<script>alert('xss')</script>test review text",
        }, follow_redirects=True)
        assert r.status_code == 200
        # Check that script tag is escaped in the response
        assert b"<script>alert" not in r.data
        assert b"&lt;script&gt;" in r.data

    def test_image_upload_rejects_non_image(self, client, login_admin, app):
        """Try uploading an .exe / .txt as product image — should be rejected."""
        from io import BytesIO
        # Get a product id (need to create one for new product endpoint)
        r = client.post("/admin/products/new", data={
            "name": "Test Product",
            "description": "test",
            "composition": "test",
            "taste": "test",
            "weight_g": "250",
            "price": "100",
            "shelf_life_days": "10",
            "stock": "5",
            "category_id": "0",
            "is_published": "y",
            # No file
        }, content_type="multipart/form-data", follow_redirects=True)
        assert r.status_code == 200
        # Now test bad file upload — use a text file masquerading as image
        from werkzeug.datastructures import FileStorage
        bad = FileStorage(stream=BytesIO(b"NOT AN IMAGE\x00\x00"), filename="evil.php", content_type="application/x-php")
        r = client.post("/admin/products/new", data={
            "name": "Bad Upload",
            "description": "x", "composition": "x", "taste": "x",
            "weight_g": "250", "price": "100", "shelf_life_days": "10", "stock": "5",
            "category_id": "0", "is_published": "y",
            "image": bad,
        }, content_type="multipart/form-data", follow_redirects=True)
        # Either 200 with error message, or product saved without the bad image
        assert r.status_code == 200
