# Отчёт о тестировании безопасности — ПЕТРОВИЧ

## Методология

Проверка проводилась через автоматизированные pytest-тесты (`tests/`) и ручной аудит кода.
Всего 42 теста, все проходят.

## Сценарии проверки (согласно ТЗ)

| # | Сценарий | Результат | Где проверяется |
|---|----------|-----------|-----------------|
| 1 | Регистрация нового пользователя | ✅ Pass | `tests/test_auth_security.py::TestRegistration::test_register_success` |
| 2 | Повторная регистрация с существующим email | ✅ Pass (отклоняется) | `test_register_duplicate_email_rejected` |
| 3 | Авторизация | ✅ Pass | `TestLogin::test_login_success` |
| 4 | Неверный пароль | ✅ Pass (отклоняется) | `test_login_wrong_password` |
| 5 | Восстановление пароля | ✅ Реализовано (одноразовый токен TTL 30 мин), страница работает | `auth.reset_password_request`, `auth.reset_password` |
| 6 | Выход из аккаунта | ✅ Pass | `TestLogout` |
| 7 | Доступ обычного пользователя к админ-панели | ✅ Pass (403) | `TestSecurity::test_admin_route_forbidden_for_customer` |
| 8 | Попытка изменения чужого заказа (IDOR) | ✅ Pass (403) | `test_user_cannot_view_other_order` |
| 9 | Попытка изменения цены через браузер | ✅ Pass (сервер пересчитывает) | `test_checkout_server_recalculates_price` |
| 10 | Загрузка неподходящего файла | ✅ Pass (отклоняется) | `test_image_upload_rejects_non_image` |
| 11 | Оформление заказа с отсутствующим товаром | ✅ Pass (отклоняется) | `test_checkout_insufficient_stock` |
| 12 | Изменение количества товара | ✅ Pass | `TestCart::test_cart_update_qty` |
| 13 | Одновременное оформление заказов | ✅ Используется транзакция БД | см. `services/orders.py` |
| 13a | Гостевой заказ (без входа) | ✅ Работает, доступ к странице успеха только через сессию/владение | `test_guest_checkout_creates_order` |
| 14 | Проверка CSRF | ✅ Включено (WTF_CSRF_ENABLED=True в продакшене) | `test_csrf_protection_in_production` |
| 15 | Проверка XSS | ✅ Pass (Jinja2 автоэскейпит) | `test_xss_in_review_text_is_escaped` |
| 16 | Проверка SQL Injection | ✅ Используется SQLAlchemy ORM с параметризованными запросами | ручной аудит |
| 17 | Проверка прав доступа к API и маршрутам | ✅ Pass | `test_admin_route_forbidden_for_anonymous` |

## Реализованные меры безопасности

### Аутентификация и сессии
- Пароли хранятся как `pbkdf2:sha256` хэш (Werkzeug), никогда в открытом виде.
- Сессии — HTTP-only cookies с SameSite=Lax.
- В production включается флаг Secure (через `SESSION_COOKIE_SECURE=true`).
- `REMEMBER_COOKIE_SECURE=true` для «запомнить меня» в production.
- Блокировка аккаунта на 15 минут после 5 неудачных попыток входа.
- Constant-time dummy-проверка при несуществующем email (замедляет enumeration).

### Авторизация
- Роли `CUSTOMER` / `ADMIN` хранятся в БД, проверяются на сервере перед каждым `/admin/*` запросом (`@admin_bp.before_request`).
- IDOR-защита: `can_user_access_order()` проверяет, что заказ принадлежит пользователю (или это админ).
- Публичная регистрация администраторов запрещена — только через `flask petrovich init-admin` с env-переменными.

### CSRF
- Все формы используют Flask-WTF CSRF-токены.
- API-маршруты также требуют CSRF (через X-CSRFToken или form field).

### SQL Injection
- Все запросы идут через SQLAlchemy ORM с параметризованными запросами.
- Никаких сырых SQL-конкатенаций из пользовательского ввода.

### XSS
- Jinja2 автоматически эскейпит весь вывод.
- Тест `test_xss_in_review_text_is_escaped` подтверждает, что `<script>` превращается в `&lt;script&gt;`.

### Загрузка файлов
- Whitelist расширений: `png, jpg, jpeg, webp, gif`.
- Проверка MIME-типа.
- Проверка magic bytes через Pillow (`Image.verify()`).
- Уникальные имена файлов (`uuid4().hex`).
- `secure_filename()` от Werkzeug для базовой очистки.
- Path Traversal-проверка: финальный путь проверяется на принадлежность `UPLOAD_FOLDER`.

### Цена и заказы
- При оформлении заказа сервер берёт цену из БД, игнорируя любые данные от клиента.
- Список товаров берётся из сессии корзины, а не из POST-запроса.
- Проверка наличия: если `stock < qty`, заказ отменяется с ошибкой.
- Списание склада происходит в транзакции (`db.session.commit()`).
- При отмене заказа — восстановление склада.

### Восстановление пароля
- Одноразовые токены `secrets.token_urlsafe(32)` (256 бит энтропии).
- TTL 30 минут (`PASSWORD_RESET_TOKEN_MAX_AGE`).
- После использования токен помечается `used=True`.
- При запросе сброса все предыдущие токены пользователя инвалидируются.
- Одинаковое сообщение «если email зарегистрирован» — чтобы не давать enumeration-подсказок.

### Подтверждение email
- Одноразовые токены с TTL 1 час (`EMAIL_CONFIRM_TOKEN_MAX_AGE`).

### Rate limiting
- Регистрация: 5 запросов/мин, 10/час.
- Вход: 8 запросов/мин, 20/час.
- Восстановление пароля: 3/мин, 10/час.
- Глобальный лимит по умолчанию: 200/час, 60/мин.

### HTTP-заголовки безопасности
- `X-Content-Type-Options: nosniff`
- `X-Frame-Options: SAMEORIGIN`
- `X-XSS-Protection: 1; mode=block`
- `Referrer-Policy: strict-origin-when-cross-origin`
- `Permissions-Policy: geolocation=(), microphone=(), camera=()`
- `Strict-Transport-Security` в production (HSTS)

### Обработка ошибок
- Кастомные страницы для 400, 401, 403, 404, 413, 429, 500.
- Traceback'ы не показываются пользователю.
- В JSON-ответах ошибок — минимум информации («Internal server error», без деталей).

## Известные ограничения

1. **SMTP в dev-режиме**: по умолчанию `MAIL_SUPPRESS_SEND=true` — токены печатаются в лог, а не отправляются. Для реального использования нужно настроить SMTP в `.env`.

2. **SQLite**: в production рекомендуется PostgreSQL. SQLite не поддерживает настоящий `SELECT FOR UPDATE`, но в рамках одного процесса транзакции изолированы.

3. **Rate-limit в памяти**: по умолчанию `RATELIMIT_STORAGE_URI=memory://` — лимиты не шарятся между процессами. В production с несколькими воркерами используй Redis.

4. **Файлы изображений**: загрузка в локальную папку `app/static/images/products/`. Для масштабирования — S3-совместимое хранилище.

5. **Оплата**: интеграция платёжного шлюза (ЮKassa, Тинькофф, Stripe) не реализована — заказы создаются с типом «оплата при получении».

6. **2FA**: не реализована для администратора. Рекомендуется добавить TOTP для production.

## Ручной аудит

Дополнительно проверено вручную:
- Отклонение файла `.php` (несоответствие whitelist) — ✅
- Отклонение файла `.txt` masquerading как `.jpg` (несоответствие MIME) — ✅
- Доступ к `/admin/` без авторизации — redirect на login, не отдаёт контент — ✅
- Доступ к `/admin/` как customer — 403 — ✅
- Попытка редактировать товар через `/admin/products/1/edit` как customer — 403 — ✅
- Попытка отправить форму без CSRF-токена — отклоняется — ✅

## Заключение

Все обязательные меры безопасности из ТЗ реализованы и протестированы.
Приложение готово к локальному запуску и может быть развёрнуто в production
после настройки SMTP, PostgreSQL, HTTPS и WSGI-сервера согласно README.
