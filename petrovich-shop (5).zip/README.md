# ПЕТРОВИЧ — интернет-магазин домашнего мармелада

Полноценный многостраничный интернет-магазин домашнего мармелада с собственным дизайном,
личным кабинетом, корзиной, оформлением заказов и защищённой административной панелью.

**Стек:** Python 3.11+, Flask, SQLAlchemy, Flask-Login, Flask-WTF, Flask-Limiter,
SQLite (с возможностью перехода на PostgreSQL), Vanilla JS, HTML5, CSS3.

Логотип бренда — собственный, поставляется в `app/static/images/logo/petrovich-logo.png`.

**Шрифты** — Golos Text и Comfortaa с полной поддержкой кириллицы, **встроены локально**
(`app/static/fonts/`). Сайт не зависит от Google Fonts и корректно выглядит без интернета
и в России.

**Администратор создаётся автоматически** при первом запуске из переменных `ADMIN_EMAIL` /
`ADMIN_PASSWORD` — отдельная команда не обязательна (но `flask --app run.py petrovich init-admin` тоже работает).

---

## Возможности

### Витрина
- Главная страница с hero-блоком, преимуществами, популярными вкусами, новинками, отзывами и FAQ.
- Каталог с фильтрами (категория, вкус, цена), сортировкой и поиском.
- Карточка товара с составом, ценой, сроком годности, отзывами и похожими товарами.
- Корзина (хранится в сессии) с добавлением, удалением, изменением количества и AJAX-обновлением.
- Оформление заказа **без обязательной регистрации** (гостевые заказы) с выбором способа
  получения (самовывоз бесплатно / доставка по Новокузнецку 25 ₽) и валидацией на сервере.
- Избранное для авторизованных пользователей.

### Аккаунты
- Регистрация с подтверждением email (токены с ограниченным сроком действия).
- Вход с защитой от перебора (блокировка после 5 неудачных попыток).
- Восстановление пароля по одноразовому токену.
- Личный кабинет: профиль, заказы, избранное, смена пароля.
- IDOR-защита: пользователь не может просматривать чужие заказы.

### Админ-панель (`/admin/`)
- Дашборд со статистикой и графиками за 14 дней.
- Управление заказами: смена статусов, отмена с восстановлением склада, фильтры.
- CRUD товаров с безопасной загрузкой изображений (проверка MIME, magic bytes через Pillow).
- Управление вкусами и категориями.
- Управление покупателями (просмотр, блокировка).
- Модерация отзывов.
- Настройки магазина (контакты, описание, тексты).

### Безопасность
- Пароли хранятся только как `pbkdf2:sha256`-хэш, никогда в открытом виде.
- Секреты — через переменные окружения (`.env`).
- CSRF-защита на всех формах.
- HTTP-only cookies, SameSite=Lax, Secure в production.
- Безопасные HTTP-заголовки (X-Content-Type-Options, X-Frame-Options, HSTS и др.).
- Rate-limit на auth-маршрутах (5 рег./мин, 8 входов/мин).
- Загрузка файлов: whitelist расширений, проверка MIME и содержимого, уникальные имена.
- Защита от Path Traversal при сохранении файла.
- Серверная проверка цены и наличия при оформлении заказа (транзакция).
- Не раскрываются traceback'ы — пользовательские страницы ошибок 400/401/403/404/413/429/500.
- Роли проверяются на сервере перед каждым admin-запросом.

---

## Структура проекта

```
petrovich/
├── app/
│   ├── __init__.py            # create_app()
│   ├── extensions.py          # db, login_manager, csrf, limiter
│   ├── cli.py                 # flask petrovich init-db / init-admin / seed
│   ├── errors.py              # обработчики ошибок
│   ├── models/                # User, Product, Flavor, Category, Order, ...
│   ├── routes/                # main, auth, shop, account, admin, api, forms
│   ├── services/              # cart, orders, mail_service, security
│   ├── templates/             # base, shop, auth, account, admin, errors, partials
│   └── static/
│       ├── css/               # base, layout, pages
│       ├── js/                # app.js
│       └── images/
│           ├── icons/sprite.svg   # все SVG-иконки
│           ├── decor/illustrations.svg  # декоративные SVG
│           ├── logo/petrovich-logo.png
│           └── products/      # загружаемые фото товаров
├── migrations/                # Flask-Migrate (пусто — db.create_all)
├── tests/                     # pytest (38 тестов)
├── config.py
├── requirements.txt
├── run.py
├── .env.example
└── README.md
```

---

## Быстрый старт

### 1. Установить зависимости

```bash
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Настроить окружение

```bash
cp .env.example .env
```

Открой `.env и заполни:
- `SECRET_KEY` — длинная случайная строка (≥ 32 символов).
- `ADMIN_EMAIL` — `siluetorg@gmail.com` (или другой).
- `ADMIN_PASSWORD` — сложный пароль (≥ 8 символов).
- `DATABASE_URL` — по умолчанию `sqlite:///petrovich.db` (файл создастся в `instance/`).
- `MAIL_*` — настройки SMTP (можно оставить `MAIL_SUPPRESS_SEND=true` — токены будут печататься в консоль).

Сгенерировать `SECRET_KEY`:
```bash
python -c "import secrets; print(secrets.token_hex(32))"
```

### 3. Инициализировать базу данных и создать администратора

```bash
flask --app run.py petrovich init-db
flask --app run.py petrovich seed        # опционально: демо-товары
# админ создастся сам при первом запуске из ADMIN_EMAIL/ADMIN_PASSWORD из .env
```

### 4. Запустить сервер

```bash
flask --app run.py run
# или
python run.py
```

Открой `http://127.0.0.1:5000` в браузере.

Вход в админку: `http://127.0.0.1:5000/auth/login` с данными из `ADMIN_EMAIL` / `ADMIN_PASSWORD`.

---

## Настройка SMTP (для подтверждения email и восстановления пароля)

1. Для Gmail создай «пароль приложения» (настройки → безопасность → двухэтапная аутентификация → пароли приложений).
2. В `.env` укажи:
   ```
   MAIL_SERVER=smtp.gmail.com
   MAIL_PORT=587
   MAIL_USE_TLS=true
   MAIL_USERNAME=your-email@gmail.com
   MAIL_PASSWORD=your-app-password
   MAIL_DEFAULT_SENDER=your-email@gmail.com
   MAIL_SUPPRESS_SEND=false
   ```
3. Перезапусти приложение.

Если `MAIL_SUPPRESS_SEND=true`, токены (например, для подтверждения email) печатаются в лог/консоль вместо отправки — удобно для разработки.

---

## Запуск тестов

```bash
pytest tests/ -v
```

Покрытие:
- `tests/test_auth_security.py` — регистрация, вход, восстановление, IDOR, XSS, CSRF, загрузка файлов.
- `tests/test_shop.py` — каталог, корзина, оформление, изменение статуса, восстановление склада.

Все 38 тестов проходят.

---

## Подготовка к production

1. **WSGI-сервер**: используй `gunicorn` (или `waitress` на Windows):
   ```bash
   pip install gunicorn
   gunicorn -w 4 -b 0.0.0.0:8000 "run:app"
   ```

2. **HTTPS обязателен**: в `.env` поставь `SESSION_COOKIE_SECURE=true` и `REMEMBER_COOKIE_SECURE=true`, иначе cookies не будут защищены.

3. **Reverse-proxy**: поставь Nginx/Caddy перед gunicorn, терминируй TLS, проксируй на 127.0.0.1:8000.

4. **PostgreSQL**: поменяй `DATABASE_URL`:
   ```
   DATABASE_URL=postgresql+psycopg2://user:password@host:5432/petrovich
   pip install psycopg2-binary
   ```

5. **Секреты**: никогда не коммить `.env`. Используй переменные окружения сервера или секрет-менеджер.

6. **Бэкапы БД**: настрой регулярный `pg_dump` (для SQLite — копия файла).

7. **Логи**: пиши в файл, ротируй. Не логируй пароли и токены.

8. **Rate-limit**: в production рассмотри переход с `memory://` на Redis:
   ```
   RATELIMIT_STORAGE_URI=redis://localhost:6379
   ```

9. **Обновления**: `pip install --upgrade -r requirements.txt` регулярно.

---

## Безопасность — что проверено

Подробный отчёт о тестировании безопасности находится в `SECURITY_REPORT.md`.

Кратко:
- ✅ Пароли — `pbkdf2:sha256`, никогда в открытом виде.
- ✅ CSRF-токены на всех формах.
- ✅ Роли проверяются серверно перед каждым `/admin/*` запросом.
- ✅ Цена заказа всегда пересчитывается на сервере из БД, ввод клиента игнорируется.
- ✅ Склад уменьшается в транзакции, при отмене восстанавливается.
- ✅ Загрузка файлов: whitelist расширений, проверка MIME и magic bytes.
- ✅ IDOR-защита на заказах.
- ✅ Rate-limit на auth-маршрутах.
- ✅ Восстановление пароля — одноразовые токены с TTL 30 мин.
- ✅ Не раскрываются traceback'ы — кастомные страницы ошибок.
- ✅ HTTP-заголовки безопасности выставляются.

---

## Лицензия

Проект создан для бренда «ПЕТРОВИЧ». Используй, изменяй и развивай по мере необходимости.

## Контакты

- Email: siluetorg@gmail.com
- Телефон: указывается в настройках магазина

Сделано с любовью к мармеладу.
