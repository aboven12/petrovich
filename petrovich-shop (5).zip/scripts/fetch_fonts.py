"""Download Cyrillic webfonts from Google Fonts and generate local fonts.css."""
import os
import re
import urllib.request

CSS_URL = (
    "https://fonts.googleapis.com/css2"
    "?family=Comfortaa:wght@500;600;700"
    "&family=Golos+Text:wght@400;500;600;700;800;900"
    "&display=swap"
)
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FONT_DIR = os.path.join(ROOT, "app", "static", "fonts")
CSS_OUT = os.path.join(ROOT, "app", "static", "css", "fonts.css")
os.makedirs(FONT_DIR, exist_ok=True)

req = urllib.request.Request(CSS_URL, headers={"User-Agent": UA})
css = urllib.request.urlopen(req, timeout=60).read().decode("utf-8")
print(f"Fetched CSS: {len(css)} bytes")

blocks = re.findall(r"/\*\s*([\w-]+)\s*\*/\s*@font-face\s*\{([^}]+)\}", css)
print(f"Font-face blocks found: {len(blocks)}")

out = []
for subset, body in blocks:
    if subset not in ("cyrillic", "latin", "cyrillic-ext", "latin-ext"):
        continue
    fam_m = re.search(r"font-family:\s*'([^']+)'", body)
    weight_m = re.search(r"font-weight:\s*(\d+)", body)
    style_m = re.search(r"font-style:\s*(\w+)", body)
    url_m = re.search(r"url\((https://[^)]+?\.woff2)\)", body)
    range_m = re.search(r"unicode-range:\s*([^;]+);", body)
    if not (fam_m and weight_m and url_m):
        continue
    fam = fam_m.group(1)
    weight = weight_m.group(1)
    style = style_m.group(1) if style_m else "normal"
    url = url_m.group(1)
    urange = range_m.group(1) if range_m else None

    fname = f"{fam.lower().replace(' ', '')}-{weight}-{subset}.woff2"
    dest = os.path.join(FONT_DIR, fname)
    r = urllib.request.Request(url, headers={"User-Agent": UA})
    data = urllib.request.urlopen(r, timeout=60).read()
    with open(dest, "wb") as f:
        f.write(data)
    size_kb = len(data) // 1024
    print(f"  {fname}: {size_kb} KB")

    ur = f"\n  unicode-range: {urange};" if urange else ""
    out.append(
        f"@font-face {{\n"
        f"  font-family: '{fam}';\n"
        f"  font-style: {style};\n"
        f"  font-weight: {weight};\n"
        f"  font-display: swap;\n"
        f"  src: url('../fonts/{fname}') format('woff2');{ur}\n"
        f"}}"
    )

with open(CSS_OUT, "w", encoding="utf-8") as f:
    f.write("/* PETROVICH local fonts (Cyrillic + Latin), self-hosted */\n")
    f.write("\n".join(out))
    f.write("\n")

print(f"\nWrote {CSS_OUT} with {len(out)} @font-face rules")
