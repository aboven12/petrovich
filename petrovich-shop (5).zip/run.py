"""Entry point: run with `flask run` or `python run.py`."""
# Load .env BEFORE anything else so config picks up the values
try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

from app import create_app

app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=app.config.get("DEBUG", False))
