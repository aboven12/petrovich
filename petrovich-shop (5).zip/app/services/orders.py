"""Order service: server-side validation, transactions, stock decrement."""
from decimal import Decimal
from datetime import datetime

from flask import current_app
from sqlalchemy import select

from app.extensions import db
from app.models.order import Order, OrderItem, OrderStatus, DeliveryMethod
from app.models.product import Product
from app.services.cart import Cart


# Доставка: самовывоз бесплатно, курьер по Новокузнецку 25 ₽.
DELIVERY_COST = {
    DeliveryMethod.PICKUP: Decimal("0"),
    DeliveryMethod.COURIER: Decimal("25"),
}


class InsufficientStockError(Exception):
    pass


class EmptyCartError(Exception):
    pass


def create_order_from_cart(
    cart: Cart,
    *,
    user,
    contact_name: str,
    contact_phone: str,
    contact_email: str | None,
    address: str | None,
    comment: str | None,
    delivery_method: DeliveryMethod,
) -> Order:
    """Create order atomically. Server recalculates prices; ignores any
    client-supplied price/quantity tampering."""

    snapshot = cart.summary_for_order()
    if not snapshot:
        raise EmptyCartError("Корзина пуста.")

    items_total = Decimal("0")
    prepared = []  # (product, qty, server_unit_price)

    # Lock products row by row via SELECT FOR UPDATE (sqlite falls back to read)
    try:
        for product, qty, _client_price in snapshot:
            # Re-fetch product under transaction
            prod = db.session.get(Product, product.id)
            if not prod or not prod.is_published:
                raise InsufficientStockError(f"Товар «{product.name}» недоступен.")
            if prod.stock < qty:
                raise InsufficientStockError(
                    f"Недостаточно «{prod.name}»: осталось {prod.stock}, нужно {qty}."
                )
            line = Decimal(prod.price) * qty
            items_total += line
            prepared.append((prod, qty, Decimal(prod.price), line))
    except InsufficientStockError:
        db.session.rollback()
        raise

    # Decrement stock
    for prod, qty, _unit_price, _line in prepared:
        prod.stock -= qty

    delivery_cost = DELIVERY_COST.get(delivery_method, Decimal("0"))
    total = items_total + delivery_cost

    order = Order(
        number=_generate_number(),
        user_id=user.id if user else None,
        guest_name=None if user else contact_name,
        guest_email=None if user else contact_email,
        guest_phone=None if user else contact_phone,
        contact_name=contact_name,
        contact_phone=contact_phone,
        contact_email=contact_email,
        address=address,
        comment=comment,
        delivery_method=delivery_method,
        status=OrderStatus.NEW,
        items_total=items_total,
        delivery_cost=delivery_cost,
        total=total,
    )
    db.session.add(order)
    db.session.flush()  # get order.id

    for prod, qty, unit_price, line_total in prepared:
        item = OrderItem(
            order_id=order.id,
            product_id=prod.id,
            product_name=prod.name,
            product_price=unit_price,
            quantity=qty,
            line_total=line_total,
        )
        db.session.add(item)

    db.session.commit()
    cart.clear()
    return order


def _generate_number() -> str:
    """Generate a unique order number like PETR-20261102-XYZ."""
    today = datetime.utcnow().strftime("%Y%m%d")
    import secrets
    suffix = secrets.token_hex(3).upper()
    number = f"PETR-{today}-{suffix}"
    # collision guard (very unlikely)
    while Order.query.filter_by(number=number).first():
        suffix = secrets.token_hex(3).upper()
        number = f"PETR-{today}-{suffix}"
    return number


def can_user_access_order(user, order: Order) -> bool:
    """IDOR protection: only the order's owner (or an admin) may view it."""
    if user is None or not user.is_authenticated:
        return False
    if user.is_admin:
        return True
    return order.user_id == user.id


def update_order_status(order: Order, new_status: OrderStatus) -> Order:
    """Transition order to new status. Restores stock on cancellation."""
    if order.status == OrderStatus.CANCELLED and new_status != OrderStatus.CANCELLED:
        raise ValueError("Отменённый заказ нельзя переоткрыть.")

    if new_status == OrderStatus.CANCELLED and order.status != OrderStatus.CANCELLED:
        # Restore stock
        for item in order.items:
            prod = item.product
            if prod:
                prod.stock += item.quantity
    order.status = new_status
    db.session.commit()
    return order
