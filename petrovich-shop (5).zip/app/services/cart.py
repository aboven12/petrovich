"""Cart service: cart stored in session as {product_id: qty}."""
from decimal import Decimal
from types import SimpleNamespace
from flask import session

from app.extensions import db
from app.models.product import Product


CART_KEY = "petrovich_cart"


class Cart:
    """Lightweight cart wrapper around session dict {product_id_str: qty}."""

    def __init__(self):
        self._items = session.setdefault(CART_KEY, {})

    @classmethod
    def current(cls) -> "Cart":
        if CART_KEY not in session:
            session[CART_KEY] = {}
        return cls()

    def add(self, product_id: int, qty: int = 1) -> int:
        sid = str(int(product_id))
        qty = max(1, int(qty))
        self._items[sid] = self._items.get(sid, 0) + qty
        session.modified = True
        return self._items[sid]

    def set_qty(self, product_id: int, qty: int) -> int:
        sid = str(int(product_id))
        qty = int(qty)
        if qty <= 0:
            self._items.pop(sid, None)
        else:
            self._items[sid] = qty
        session.modified = True
        return self._items.get(sid, 0)

    def remove(self, product_id: int) -> None:
        sid = str(int(product_id))
        self._items.pop(sid, None)
        session.modified = True

    def clear(self) -> None:
        session.pop(CART_KEY, None)
        session.modified = True

    @property
    def raw(self) -> dict:
        return dict(self._items)

    @property
    def is_empty(self) -> bool:
        return len(self._items) == 0

    @property
    def total_items(self) -> int:
        return sum(int(q) for q in self._items.values())

    def detailed(self):
        """Returns SimpleNamespace with .items (list of dicts), .items_total,
        .total, .count. Attributes avoid clashing with dict.items()."""
        if not self._items:
            return SimpleNamespace(items=[], items_total=Decimal("0"),
                                   total=Decimal("0"), count=0)

        ids = [int(pid) for pid in self._items.keys()]
        products = {p.id: p for p in Product.query.filter(Product.id.in_(ids)).all()}

        items = []
        items_total = Decimal("0")
        for pid_str, qty in self._items.items():
            pid = int(pid_str)
            prod = products.get(pid)
            if not prod:
                continue
            line = Decimal(prod.price) * qty
            items_total += line
            items.append({
                "product": prod,
                "qty": int(qty),
                "unit_price": Decimal(prod.price),
                "line_total": line,
            })

        return SimpleNamespace(
            items=items,
            items_total=items_total,
            total=items_total,  # delivery added at checkout
            count=sum(i["qty"] for i in items),
        )

    def summary_for_order(self):
        """Snapshot for order creation: list of (product, qty, server_price)."""
        info = self.detailed()
        return [
            (item["product"], item["qty"], item["unit_price"])
            for item in info.items
        ]
