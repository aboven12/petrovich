"""Email service: confirmation links + password reset links.
If MAIL_SUPPRESS_SEND is True, tokens are printed to console/log instead."""
import logging
from flask import current_app, url_for

log = logging.getLogger("petrovich.mail")


def _send_mail(to: str, subject: str, html: str) -> bool:
    """Try to send an email. Returns True on success, False on suppression/failure."""
    if current_app.config.get("MAIL_SUPPRESS_SEND", True):
        log.info("[MAIL suppressed] to=%s subject=%s\n%s", to, subject, html)
        return False

    try:
        import smtplib
        from email.mime.text import MIMEText
        from email.mime.multipart import MIMEMultipart

        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"] = current_app.config["MAIL_DEFAULT_SENDER"]
        msg["To"] = to
        msg.attach(MIMEText(html, "html", "utf-8"))

        server = current_app.config["MAIL_SERVER"]
        port = current_app.config["MAIL_PORT"]
        use_tls = current_app.config["MAIL_USE_TLS"]
        use_ssl = current_app.config["MAIL_USE_SSL"]
        user = current_app.config.get("MAIL_USERNAME")
        password = current_app.config.get("MAIL_PASSWORD")

        if use_ssl:
            with smtplib.SMTP_SSL(server, port, timeout=15) as smtp:
                if user:
                    smtp.login(user, password)
                smtp.send_message(msg)
        else:
            with smtplib.SMTP(server, port, timeout=15) as smtp:
                if use_tls:
                    smtp.starttls()
                if user:
                    smtp.login(user, password)
                smtp.send_message(msg)
        return True
    except Exception as e:
        log.error("Mail send failed: %s", e)
        return False


def send_email_confirmation(user, token_value: str) -> None:
    link = url_for("auth.confirm_email", token=token_value, _external=True)
    html = f"""
    <html><body style="font-family: Arial, sans-serif; color:#222;">
      <h2 style="color:#E63E3E;">ПЕТРОВИЧ — подтверждение почты</h2>
      <p>Здравствуйте, {user.name}!</p>
      <p>Подтвердите ваш email, чтобы закончить регистрацию:</p>
      <p><a href="{link}" style="display:inline-block;padding:12px 24px;background:#E63E3E;color:#fff;border-radius:10px;text-decoration:none;">Подтвердить почту</a></p>
      <p style="color:#888;font-size:12px;">Ссылка действительна 1 час. Если вы не регистрировались — просто проигнорируйте письмо.</p>
    </body></html>
    """
    _send_mail(user.email, "ПЕТРОВИЧ — подтверждение email", html)


def send_password_reset(user, token_value: str) -> None:
    link = url_for("auth.reset_password", token=token_value, _external=True)
    html = f"""
    <html><body style="font-family: Arial, sans-serif; color:#222;">
      <h2 style="color:#E63E3E;">ПЕТРОВИЧ — восстановление пароля</h2>
      <p>Здравствуйте, {user.name}!</p>
      <p>Чтобы задать новый пароль, перейдите по ссылке:</p>
      <p><a href="{link}" style="display:inline-block;padding:12px 24px;background:#E63E3E;color:#fff;border-radius:10px;text-decoration:none;">Сбросить пароль</a></p>
      <p style="color:#888;font-size:12px;">Ссылка действительна 30 минут. Если вы не запрашивали сброс — проигнорируйте письмо.</p>
    </body></html>
    """
    _send_mail(user.email, "ПЕТРОВИЧ — восстановление пароля", html)
