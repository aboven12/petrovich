"""Security helpers: file validation, slug sanity, role checks."""
import os
import io
from pathlib import Path

from flask import current_app, abort
from flask_login import current_user
from werkzeug.utils import secure_filename

from app.models.user import Role

# Pillow is optional — we degrade gracefully if it's not installed.
try:
    from PIL import Image as _PIL_Image
    _HAS_PIL = True
except Exception:
    _PIL_Image = None
    _HAS_PIL = False


def allowed_file(filename: str) -> bool:
    """Check filename extension against whitelist."""
    if not filename or "." not in filename:
        return False
    ext = filename.rsplit(".", 1)[1].lower()
    return ext in current_app.config["ALLOWED_IMAGE_EXTENSIONS"]


# Magic bytes per format — used as fallback when Pillow is missing.
_MAGIC = [
    (b"\x89PNG\r\n\x1a\n", "PNG"),
    (b"\xff\xd8\xff", "JPEG"),
    (b"GIF87a", "GIF"),
    (b"GIF89a", "GIF"),
    (b"RIFF", "WEBP"),  # also needs WEBPVP at offset 8, but RIFF is enough for whitelist
]


def _detect_format_by_magic(data: bytes) -> str | None:
    """Detect image format from magic bytes without Pillow."""
    for prefix, fmt in _MAGIC:
        if data.startswith(prefix):
            # For RIFF (could be WAV, AVI, etc.), check WEBP marker at offset 8
            if fmt == "WEBP" and len(data) >= 12:
                if data[8:12] == b"WEBP":
                    return "WEBP"
                return None
            return fmt
    return None


def validate_image_stream(file_storage) -> bytes:
    """Read file contents, verify MIME and magic bytes. Uses Pillow if available,
    otherwise falls back to magic-byte checking."""
    data = file_storage.read()
    if len(data) > current_app.config["MAX_CONTENT_LENGTH"]:
        raise ValueError("Файл слишком большой.")
    if len(data) < 24:
        raise ValueError("Файл слишком маленький или повреждён.")

    # Check declared mime
    declared_mime = getattr(file_storage, "mimetype", "") or ""
    if declared_mime and declared_mime not in current_app.config["ALLOWED_IMAGE_MIMES"]:
        raise ValueError("Недопустимый тип файла.")

    if _HAS_PIL:
        # Verify with Pillow (preferred)
        try:
            img = _PIL_Image.open(io.BytesIO(data))
            img.verify()
        except Exception:
            raise ValueError("Файл не является корректным изображением.")
        # Re-open to get format (verify() invalidates object)
        try:
            img = _PIL_Image.open(io.BytesIO(data))
            fmt = (img.format or "").upper()
            if fmt not in {"PNG", "JPEG", "WEBP", "GIF"}:
                raise ValueError("Недопустимый формат изображения.")
        except Exception:
            raise ValueError("Не удалось обработать изображение.")
    else:
        # Fallback: magic bytes
        fmt = _detect_format_by_magic(data)
        if not fmt:
            raise ValueError("Файл не является корректным изображением (Pillow не установлен, проверка по сигнатуре не пройдена).")

    return data


def save_uploaded_image(file_storage, prefix: str = "p") -> str:
    """Validate, save image to UPLOAD_FOLDER. Returns relative filename."""
    if not file_storage or not file_storage.filename:
        raise ValueError("Файл не выбран.")
    if not allowed_file(file_storage.filename):
        raise ValueError("Недопустимое расширение файла.")

    data = validate_image_stream(file_storage)
    base = secure_filename(Path(file_storage.filename).stem) or prefix
    base = base[:40]
    ext = file_storage.filename.rsplit(".", 1)[1].lower()

    # Generate unique filename to avoid Path Traversal / collisions
    import uuid
    filename = f"{prefix}_{uuid.uuid4().hex[:12]}_{base}.{ext}"

    upload_dir = Path(current_app.root_path) / "static" / "images" / "products"
    upload_dir.mkdir(parents=True, exist_ok=True)

    # Final safety: ensure the resolved path is inside upload_dir
    dest = (upload_dir / filename).resolve()
    if not str(dest).startswith(str(upload_dir.resolve())):
        raise ValueError("Недопустимый путь файла.")
    dest.write_bytes(data)

    return filename


def require_admin():
    """Abort 403 unless current_user is admin. Call inside admin routes."""
    if not current_user.is_authenticated or not current_user.is_admin:
        abort(403)


def require_login():
    """Abort 401 unless current_user is authenticated."""
    if not current_user.is_authenticated:
        abort(401)
