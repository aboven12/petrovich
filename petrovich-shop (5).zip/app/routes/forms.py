"""Forms used across auth, shop, account, admin."""
from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed, FileSize
from wtforms import (
    StringField,
    PasswordField,
    TextAreaField,
    IntegerField,
    SelectField,
    BooleanField,
    SubmitField,
    DecimalField,
)
from wtforms.validators import (
    DataRequired,
    Email,
    EqualTo,
    Length,
    Optional,
    NumberRange,
    ValidationError,
    Regexp,
)

from app.models.user import User, Role
from app.extensions import db


PHONE_RE = r"^[+]?[0-9\s\-\(\)]{7,20}$"


class RegistrationForm(FlaskForm):
    name = StringField("Имя", validators=[DataRequired(), Length(2, 120)])
    email = StringField("Email", validators=[DataRequired(), Email(check_deliverability=False), Length(5, 180)])
    password = PasswordField("Пароль", validators=[DataRequired(), Length(8, 128)])
    confirm = PasswordField("Повтор пароля", validators=[DataRequired(), EqualTo("password", message="Пароли не совпадают.")])
    agree = BooleanField("Я согласен с условиями обработки данных", validators=[DataRequired()])
    submit = SubmitField("Зарегистрироваться")

    def validate_email(self, field):
        if User.query.filter(db.func.lower(User.email) == field.data.lower()).first():
            raise ValidationError("Этот email уже зарегистрирован.")


class LoginForm(FlaskForm):
    email = StringField("Email", validators=[DataRequired(), Email(check_deliverability=False), Length(5, 180)])
    password = PasswordField("Пароль", validators=[DataRequired(), Length(1, 128)])
    remember = BooleanField("Запомнить меня")
    submit = SubmitField("Войти")


class PasswordResetRequestForm(FlaskForm):
    email = StringField("Email", validators=[DataRequired(), Email(check_deliverability=False)])
    submit = SubmitField("Отправить ссылку")


class PasswordResetForm(FlaskForm):
    password = PasswordField("Новый пароль", validators=[DataRequired(), Length(8, 128)])
    confirm = PasswordField("Повторите пароль", validators=[DataRequired(), EqualTo("password")])
    submit = SubmitField("Сбросить пароль")


class CheckoutForm(FlaskForm):
    contact_name = StringField("Имя", validators=[DataRequired(), Length(2, 120)])
    contact_phone = StringField("Телефон", validators=[DataRequired(), Regexp(PHONE_RE, message="Введите корректный телефон.")])
    contact_email = StringField("Email", validators=[Optional(), Email(check_deliverability=False), Length(0, 180)])
    delivery_method = SelectField(
        "Способ получения",
        coerce=str,
        choices=[("pickup", "Самовывоз — бесплатно"), ("courier", "Доставка по Новокузнецку — 25 ₽")],
        validators=[DataRequired()],
    )
    address = TextAreaField("Адрес доставки", validators=[Optional(), Length(0, 500)])
    comment = TextAreaField("Комментарий к заказу", validators=[Optional(), Length(0, 1000)])
    submit = SubmitField("Оформить заказ")

    DELIVERY_CHOICES = {"pickup", "courier"}

    def validate(self, *args, **kwargs):
        if not super().validate(*args, **kwargs):
            return False
        if self.delivery_method.data not in self.DELIVERY_CHOICES:
            self.delivery_method.errors.append("Выберите способ получения.")
            return False
        if self.delivery_method.data == "courier" and not (self.address.data or "").strip():
            self.address.errors.append("Укажите адрес для доставки.")
            return False
        return True


class ReviewForm(FlaskForm):
    rating = SelectField("Оценка", coerce=int, choices=[(5, "5"), (4, "4"), (3, "3"), (2, "2"), (1, "1")], validators=[DataRequired()])
    text = TextAreaField("Отзыв", validators=[DataRequired(), Length(10, 1000)])
    submit = SubmitField("Отправить отзыв")


class ProfileForm(FlaskForm):
    name = StringField("Имя", validators=[DataRequired(), Length(2, 120)])
    phone = StringField("Телефон", validators=[Optional(), Regexp(PHONE_RE)])
    address = TextAreaField("Адрес", validators=[Optional(), Length(0, 500)])
    submit = SubmitField("Сохранить")


class PasswordChangeForm(FlaskForm):
    current = PasswordField("Текущий пароль", validators=[DataRequired()])
    new = PasswordField("Новый пароль", validators=[DataRequired(), Length(8, 128)])
    confirm = PasswordField("Повторите новый пароль", validators=[DataRequired(), EqualTo("new")])
    submit = SubmitField("Сменить пароль")


# ----- Admin forms -----

class ProductForm(FlaskForm):
    name = StringField("Название", validators=[DataRequired(), Length(2, 160)])
    description = TextAreaField("Описание", validators=[Optional(), Length(0, 2000)])
    composition = TextAreaField("Состав", validators=[Optional(), Length(0, 1000)])
    taste = StringField("Вкус (кратко)", validators=[Optional(), Length(0, 120)])
    weight_g = IntegerField("Вес, г", validators=[DataRequired(), NumberRange(1, 10000)])
    price = DecimalField("Цена, ₽", validators=[DataRequired(), NumberRange(min=0)])
    old_price = DecimalField("Старая цена, ₽", validators=[Optional(), NumberRange(min=0)])
    shelf_life_days = IntegerField("Срок годности, дней", validators=[DataRequired(), NumberRange(1, 365)])
    storage_conditions = StringField("Условия хранения", validators=[Optional(), Length(0, 255)])
    stock = IntegerField("На складе", validators=[DataRequired(), NumberRange(min=0)])
    category_id = SelectField("Категория", coerce=int, validators=[Optional()])
    is_published = BooleanField("Опубликован")
    is_popular = BooleanField("Популярный")
    is_new = BooleanField("Новинка")
    image = FileField("Фотография", validators=[
        Optional(),
        FileAllowed(["png", "jpg", "jpeg", "webp", "gif"], "Только изображения."),
        FileSize(max_size=5 * 1024 * 1024),
    ])
    submit = SubmitField("Сохранить")


class FlavorForm(FlaskForm):
    name = StringField("Название", validators=[DataRequired(), Length(2, 80)])
    description = TextAreaField("Описание", validators=[Optional(), Length(0, 500)])
    color_hex = StringField("Цвет (HEX)", validators=[Optional(), Length(0, 9)])
    image = FileField("Иконка вкуса", validators=[
        Optional(),
        FileAllowed(["png", "jpg", "jpeg", "webp", "gif"], "Только изображения."),
        FileSize(max_size=2 * 1024 * 1024),
    ])
    submit = SubmitField("Сохранить")


class CategoryForm(FlaskForm):
    name = StringField("Название", validators=[DataRequired(), Length(2, 80)])
    description = TextAreaField("Описание", validators=[Optional(), Length(0, 500)])
    is_active = BooleanField("Активна")
    submit = SubmitField("Сохранить")


class ShopSettingsForm(FlaskForm):
    shop_name = StringField("Название магазина", validators=[DataRequired(), Length(2, 120)])
    tagline = StringField("Слоган", validators=[Optional(), Length(0, 255)])
    phone = StringField("Телефон", validators=[Optional(), Length(0, 40)])
    email = StringField("Email", validators=[Optional(), Email(), Length(0, 180)])
    address = TextAreaField("Адрес", validators=[Optional(), Length(0, 500)])
    description = TextAreaField("Описание", validators=[Optional(), Length(0, 2000)])
    delivery_info = TextAreaField("Доставка", validators=[Optional(), Length(0, 2000)])
    payment_info = TextAreaField("Оплата", validators=[Optional(), Length(0, 2000)])
    homepage_text = TextAreaField("Текст на главной", validators=[Optional(), Length(0, 2000)])
    submit = SubmitField("Сохранить настройки")


class OrderStatusForm(FlaskForm):
    status = SelectField("Статус", coerce=str, validators=[DataRequired()])
    admin_comment = TextAreaField("Внутренний комментарий", validators=[Optional(), Length(0, 1000)])
    submit = SubmitField("Обновить")


class AdminUserBlockForm(FlaskForm):
    is_active_user = BooleanField("Заблокирован")
    submit = SubmitField("Сохранить")
