"""Main site routes: home, contacts, faq, about."""
from flask import Blueprint, render_template, current_app, request, flash, redirect, url_for

from app.extensions import db
from app.models.product import Product, Category, Flavor
from app.models.settings import ShopSettings
from app.models.review import Review
from app.models.message import Message

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
def index():
    popular = Product.query.filter_by(is_published=True, is_popular=True).order_by(Product.rating.desc()).limit(8).all()
    new_products = Product.query.filter_by(is_published=True, is_new=True).order_by(Product.created_at.desc()).limit(8).all()
    categories = Category.query.filter_by(is_active=True).all()
    flavors = Flavor.query.order_by(Flavor.name).all()
    reviews = Review.query.filter_by(is_approved=True).order_by(Review.created_at.desc()).limit(6).all()
    settings = ShopSettings.get()
    return render_template(
        "shop/index.html",
        popular=popular,
        new_products=new_products,
        categories=categories,
        flavors=flavors,
        reviews=reviews,
        settings=settings,
    )


@main_bp.route("/about")
def about():
    settings = ShopSettings.get()
    return render_template("shop/about.html", settings=settings)


@main_bp.route("/contacts", methods=["GET", "POST"])
def contacts():
    settings = ShopSettings.get()
    if request.method == "POST":
        name = (request.form.get("name") or "").strip()
        contact = (request.form.get("contact") or "").strip()
        text = (request.form.get("text") or "").strip()
        if not name or not contact or len(text) < 5:
            flash("Заполните имя, контакт и сообщение (от 5 символов).", "error")
        else:
            msg = Message(name=name[:120], contact=contact[:180], text=text[:3000])
            db.session.add(msg)
            db.session.commit()
            flash("Спасибо! Мы свяжемся с вами в течение дня.", "success")
            return redirect(url_for("main.contacts"))
    return render_template("shop/contacts.html", settings=settings)


@main_bp.route("/faq")
def faq():
    settings = ShopSettings.get()
    faqs = [
        ("Из чего сделан мармелад «ПЕТРОВИЧ»?", "Агар-агар, фруктовые соки и пюре, мёд, сахар и немного лимонной кислоты. Никаких консервантов и красителей."),
        ("Сколько хранится мармелад?", "До 10 дней в закрытой таре при комнатной температуре. В холодильник убирать не нужно — отсыреет и слипнется."),
        ("Как получить заказ?", "Самовывоз — бесплатно. Доставка по Новокузнецку — 25 ₽. Удобное время согласуем по телефону."),
        ("Можно ли заказать оптом?", "Да. Напишите нам на почту — обсудим оптовые цены и тиражи."),
        ("Делаете подарочные наборы?", "Да, мы упаковываем мармелад в крафтовые коробки с лентой и биркой. Идеально для подарка."),
        ("Как оплатить заказ?", "Наличными или картой при получении — когда вручаем заказ."),
    ]
    return render_template("shop/faq.html", faqs=faqs, settings=settings)
