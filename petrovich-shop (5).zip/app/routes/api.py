"""JSON API: favorites toggle, cart operations, stats for admin."""
from flask import Blueprint, request, jsonify, abort
from flask_login import current_user, login_required

from app.extensions import db, csrf
from app.models.product import Product
from app.models.favorite import Favorite
from app.services.cart import Cart


api_bp = Blueprint("api", __name__)


@api_bp.route("/favorite/toggle", methods=["POST"])
@login_required
def toggle_favorite():
    product_id = request.form.get("product_id", type=int) or (
        request.get_json(silent=True) or {}
    ).get("product_id")
    if not product_id:
        return jsonify({"ok": False, "error": "Нет product_id"}), 400
    prod = Product.query.filter_by(id=product_id, is_published=True).first()
    if not prod:
        return jsonify({"ok": False, "error": "Товар не найден"}), 404
    fav = Favorite.query.filter_by(user_id=current_user.id, product_id=product_id).first()
    if fav:
        db.session.delete(fav)
        db.session.commit()
        return jsonify({"ok": True, "is_favorite": False})
    fav = Favorite(user_id=current_user.id, product_id=product_id)
    db.session.add(fav)
    db.session.commit()
    return jsonify({"ok": True, "is_favorite": True})


@api_bp.route("/cart/count")
def cart_count():
    cart = Cart.current()
    return jsonify({"count": cart.total_items})
