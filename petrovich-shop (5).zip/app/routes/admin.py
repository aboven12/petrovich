"""Admin panel: dashboard, orders, products, flavors, categories, users, settings."""
from datetime import datetime, timedelta
from decimal import Decimal

from flask import (
    Blueprint, render_template, redirect, url_for, flash, request,
    abort, current_app, jsonify,
)
from flask_login import current_user, login_required

from app.extensions import db
from app.models.user import User, Role
from app.models.product import Product, Category, Flavor, slugify
from app.models.order import Order, OrderStatus, OrderItem, DeliveryMethod
from app.models.settings import ShopSettings
from app.models.review import Review
from app.models.message import Message
from app.routes.forms import (
    ProductForm, FlavorForm, CategoryForm, ShopSettingsForm,
    OrderStatusForm, AdminUserBlockForm,
)
from app.services.security import require_admin, save_uploaded_image
from app.services.orders import update_order_status


admin_bp = Blueprint("admin", __name__)


@admin_bp.context_processor
def _inject_unread_messages():
    try:
        return {"unread_messages": Message.query.filter_by(is_read=False).count()}
    except Exception:
        return {"unread_messages": 0}


@admin_bp.before_request
@login_required
def _guard():
    """Server-side role check on every admin request."""
    if not current_user.is_admin:
        abort(403)


# ===================== Dashboard =====================

@admin_bp.route("/")
def dashboard():
    from sqlalchemy import func

    now = datetime.utcnow()
    week_ago = now - timedelta(days=7)
    month_ago = now - timedelta(days=30)

    stats = {
        "orders_total": Order.query.count(),
        "orders_new": Order.query.filter_by(status=OrderStatus.NEW).count(),
        "orders_processing": Order.query.filter(
            Order.status.in_([OrderStatus.CONFIRMED, OrderStatus.COOKING])
        ).count(),
        "orders_completed": Order.query.filter_by(status=OrderStatus.COMPLETED).count(),
        "products_total": Product.query.count(),
        "products_published": Product.query.filter_by(is_published=True).count(),
        "users_total": User.query.filter_by(role=Role.CUSTOMER).count(),
        "revenue_total": db.session.query(func.coalesce(func.sum(Order.total), 0)).filter(
            Order.status != OrderStatus.CANCELLED
        ).scalar() or 0,
        "revenue_month": db.session.query(func.coalesce(func.sum(Order.total), 0)).filter(
            Order.status != OrderStatus.CANCELLED,
            Order.created_at >= month_ago,
        ).scalar() or 0,
        "orders_week": Order.query.filter(Order.created_at >= week_ago).count(),
    }

    # Simple chart data: revenue per day for last 14 days
    days = []
    revenue_series = []
    orders_series = []
    for i in range(13, -1, -1):
        day_start = (now - timedelta(days=i)).replace(hour=0, minute=0, second=0, microsecond=0)
        day_end = day_start + timedelta(days=1)
        rev = db.session.query(func.coalesce(func.sum(Order.total), 0)).filter(
            Order.status != OrderStatus.CANCELLED,
            Order.created_at >= day_start,
            Order.created_at < day_end,
        ).scalar() or 0
        cnt = Order.query.filter(
            Order.created_at >= day_start,
            Order.created_at < day_end,
        ).count()
        days.append(day_start.strftime("%d.%m"))
        revenue_series.append(float(rev))
        orders_series.append(cnt)

    recent_orders = (
        Order.query.order_by(Order.created_at.desc()).limit(8).all()
    )

    # Top products by sold quantity
    top_products = (
        db.session.query(
            Product.name,
            func.coalesce(func.sum(OrderItem.quantity), 0).label("sold"),
        )
        .join(OrderItem, OrderItem.product_id == Product.id)
        .group_by(Product.id)
        .order_by(func.sum(OrderItem.quantity).desc())
        .limit(5)
        .all()
    )

    return render_template(
        "admin/dashboard.html",
        stats=stats,
        days=days,
        revenue_series=revenue_series,
        orders_series=orders_series,
        recent_orders=recent_orders,
        top_products=top_products,
        settings=ShopSettings.get(),
    )


# ===================== Orders =====================

@admin_bp.route("/orders")
def orders_list():
    status = request.args.get("status")
    date_from = request.args.get("date_from")
    date_to = request.args.get("date_to")
    q = request.args.get("q", "").strip()

    query = Order.query
    if status:
        try:
            status_enum = OrderStatus(status)
            query = query.filter(Order.status == status_enum)
        except ValueError:
            pass
    if date_from:
        try:
            d = datetime.strptime(date_from, "%Y-%m-%d")
            query = query.filter(Order.created_at >= d)
        except ValueError:
            pass
    if date_to:
        try:
            d = datetime.strptime(date_to, "%Y-%m-%d") + timedelta(days=1)
            query = query.filter(Order.created_at < d)
        except ValueError:
            pass
    if q:
        like = f"%{q}%"
        query = query.filter(
            db.or_(
                Order.number.ilike(like),
                Order.contact_name.ilike(like),
                Order.contact_phone.ilike(like),
                Order.contact_email.ilike(like),
            )
        )

    page = request.args.get("page", 1, type=int)
    pagination = query.order_by(Order.created_at.desc()).paginate(page=page, per_page=20, error_out=False)

    return render_template(
        "admin/orders.html",
        orders=pagination.items,
        pagination=pagination,
        statuses=OrderStatus,
        selected_status=status or "",
        date_from=date_from or "",
        date_to=date_to or "",
        q=q,
        settings=ShopSettings.get(),
    )


@admin_bp.route("/orders/<int:order_id>", methods=["GET", "POST"])
def order_detail(order_id):
    order = Order.query.get_or_404(order_id)
    form = OrderStatusForm()
    form.status.choices = [(s.value, s.label) for s in OrderStatus]
    if form.validate_on_submit():
        try:
            new_status = OrderStatus(form.status.data)
            order.admin_comment = (form.admin_comment.data or "").strip() or None
            update_order_status(order, new_status)
            flash(f"Заказ {order.number}: статус «{new_status.label}».", "success")
        except ValueError as e:
            flash(str(e), "error")
        return redirect(url_for("admin.order_detail", order_id=order.id))
    else:
        form.status.data = order.status.value
        form.admin_comment.data = order.admin_comment or ""
    return render_template("admin/order_detail.html", order=order, form=form, statuses=OrderStatus, settings=ShopSettings.get())


@admin_bp.route("/orders/<int:order_id>/cancel", methods=["POST"])
def order_cancel(order_id):
    order = Order.query.get_or_404(order_id)
    try:
        update_order_status(order, OrderStatus.CANCELLED)
        flash(f"Заказ {order.number} отменён. Склад восстановлен.", "info")
    except ValueError as e:
        flash(str(e), "error")
    return redirect(url_for("admin.order_detail", order_id=order.id))


# ===================== Products =====================

@admin_bp.route("/products")
def products_list():
    page = request.args.get("page", 1, type=int)
    q = (request.args.get("q") or "").strip()
    query = Product.query
    if q:
        like = f"%{q}%"
        query = query.filter(Product.name.ilike(like))
    pagination = query.order_by(Product.created_at.desc()).paginate(page=page, per_page=20, error_out=False)
    return render_template(
        "admin/products.html",
        products=pagination.items,
        pagination=pagination,
        q=q,
        settings=ShopSettings.get(),
    )


@admin_bp.route("/products/new", methods=["GET", "POST"])
@admin_bp.route("/products/<int:product_id>/edit", methods=["GET", "POST"])
def product_edit(product_id=None):
    prod = Product.query.get_or_404(product_id) if product_id else Product()
    form = ProductForm(obj=prod)
    form.category_id.choices = [(0, "— без категории —")] + [
        (c.id, c.name) for c in Category.query.order_by(Category.name).all()
    ]
    if form.validate_on_submit():
        prod.name = form.name.data.strip()
        prod.slug = slugify(prod.name) + (f"-{prod.id}" if prod.id else "")
        prod.description = form.description.data
        prod.composition = form.composition.data
        prod.taste = form.taste.data
        prod.weight_g = form.weight_g.data
        prod.price = form.price.data
        prod.old_price = form.old_price.data or None
        prod.shelf_life_days = form.shelf_life_days.data
        prod.storage_conditions = form.storage_conditions.data or prod.storage_conditions
        prod.stock = form.stock.data
        prod.category_id = form.category_id.data or None
        prod.is_published = form.is_published.data
        prod.is_popular = form.is_popular.data
        prod.is_new = form.is_new.data

        # Image upload (safe)
        if form.image.data:
            try:
                filename = save_uploaded_image(form.image.data, prefix="prod")
                prod.image = filename
            except ValueError as e:
                flash(str(e), "error")
                return render_template("admin/product_edit.html", form=form, product=prod, settings=ShopSettings.get())

        if not prod.id:
            db.session.add(prod)
            db.session.flush()
            # Ensure unique slug
            base = slugify(prod.name) or f"product-{prod.id}"
            prod.slug = f"{base}-{prod.id}"
        db.session.commit()
        flash(f"Товар «{prod.name}» сохранён.", "success")
        return redirect(url_for("admin.products_list"))
    return render_template("admin/product_edit.html", form=form, product=prod, settings=ShopSettings.get())


@admin_bp.route("/products/<int:product_id>/delete", methods=["POST"])
def product_delete(product_id):
    prod = Product.query.get_or_404(product_id)
    name = prod.name
    db.session.delete(prod)
    db.session.commit()
    flash(f"Товар «{name}» удалён.", "info")
    return redirect(url_for("admin.products_list"))


@admin_bp.route("/products/<int:product_id>/toggle", methods=["POST"])
def product_toggle(product_id):
    prod = Product.query.get_or_404(product_id)
    prod.is_published = not prod.is_published
    db.session.commit()
    flash(f"Товар «{prod.name}»: {'опубликован' if prod.is_published else 'скрыт'}.", "info")
    return redirect(url_for("admin.products_list"))


# ===================== Flavors =====================

@admin_bp.route("/flavors")
def flavors_list():
    flavors = Flavor.query.order_by(Flavor.name).all()
    return render_template("admin/flavors.html", flavors=flavors, settings=ShopSettings.get())


@admin_bp.route("/flavors/new", methods=["GET", "POST"])
@admin_bp.route("/flavors/<int:flavor_id>/edit", methods=["GET", "POST"])
def flavor_edit(flavor_id=None):
    flavor = Flavor.query.get_or_404(flavor_id) if flavor_id else Flavor()
    form = FlavorForm(obj=flavor)
    if form.validate_on_submit():
        flavor.name = form.name.data.strip()
        flavor.slug = slugify(flavor.name)
        flavor.description = form.description.data
        color = (form.color_hex.data or "").strip()
        if color and not color.startswith("#"):
            color = "#" + color
        flavor.color_hex = color or "#FF6B9D"
        if form.image.data:
            try:
                filename = save_uploaded_image(form.image.data, prefix="flavor")
                flavor.image = filename
            except ValueError as e:
                flash(str(e), "error")
                return render_template("admin/flavor_edit.html", form=form, flavor=flavor, settings=ShopSettings.get())
        if not flavor.id:
            db.session.add(flavor)
        db.session.commit()
        flash(f"Вкус «{flavor.name}» сохранён.", "success")
        return redirect(url_for("admin.flavors_list"))
    return render_template("admin/flavor_edit.html", form=form, flavor=flavor, settings=ShopSettings.get())


@admin_bp.route("/flavors/<int:flavor_id>/delete", methods=["POST"])
def flavor_delete(flavor_id):
    flavor = Flavor.query.get_or_404(flavor_id)
    # Detach from products
    flavor.products = []
    db.session.commit()
    db.session.delete(flavor)
    db.session.commit()
    flash(f"Вкус «{flavor.name}» удалён.", "info")
    return redirect(url_for("admin.flavors_list"))


# ===================== Categories =====================

@admin_bp.route("/categories")
def categories_list():
    cats = Category.query.order_by(Category.name).all()
    return render_template("admin/categories.html", categories=cats, settings=ShopSettings.get())


@admin_bp.route("/categories/new", methods=["GET", "POST"])
@admin_bp.route("/categories/<int:category_id>/edit", methods=["GET", "POST"])
def category_edit(category_id=None):
    cat = Category.query.get_or_404(category_id) if category_id else Category()
    form = CategoryForm(obj=cat)
    if form.validate_on_submit():
        cat.name = form.name.data.strip()
        cat.slug = slugify(cat.name)
        cat.description = form.description.data
        cat.is_active = form.is_active.data
        if not cat.id:
            db.session.add(cat)
        db.session.commit()
        flash(f"Категория «{cat.name}» сохранена.", "success")
        return redirect(url_for("admin.categories_list"))
    return render_template("admin/category_edit.html", form=form, category=cat, settings=ShopSettings.get())


@admin_bp.route("/categories/<int:category_id>/delete", methods=["POST"])
def category_delete(category_id):
    cat = Category.query.get_or_404(category_id)
    name = cat.name
    db.session.delete(cat)
    db.session.commit()
    flash(f"Категория «{name}» удалена.", "info")
    return redirect(url_for("admin.categories_list"))


# ===================== Users =====================

@admin_bp.route("/users")
def users_list():
    q = (request.args.get("q") or "").strip()
    query = User.query.filter_by(role=Role.CUSTOMER)
    if q:
        like = f"%{q}%"
        query = query.filter(db.or_(User.name.ilike(like), User.email.ilike(like)))
    page = request.args.get("page", 1, type=int)
    pagination = query.order_by(User.created_at.desc()).paginate(page=page, per_page=20, error_out=False)
    return render_template("admin/users.html", users=pagination.items, pagination=pagination, q=q, settings=ShopSettings.get())


@admin_bp.route("/users/<int:user_id>", methods=["GET", "POST"])
def user_detail(user_id):
    user = User.query.get_or_404(user_id)
    if user.role == Role.ADMIN:
        flash("Нельзя редактировать администратора.", "error")
        return redirect(url_for("admin.users_list"))
    form = AdminUserBlockForm(obj=user)
    if form.validate_on_submit():
        # Checkbox semantics: checked = block
        user.is_active_user = not form.is_active_user.data
        db.session.commit()
        flash(f"Пользователь {user.email}: {'заблокирован' if not user.is_active_user else 'активен'}.", "info")
        return redirect(url_for("admin.user_detail", user_id=user.id))
    else:
        form.is_active_user.data = not user.is_active_user
    orders = Order.query.filter_by(user_id=user.id).order_by(Order.created_at.desc()).limit(20).all()
    return render_template("admin/user_detail.html", user=user, form=form, orders=orders, settings=ShopSettings.get())


# ===================== Reviews =====================

@admin_bp.route("/reviews")
def reviews_list():
    reviews = Review.query.order_by(Review.created_at.desc()).all()
    return render_template("admin/reviews.html", reviews=reviews, settings=ShopSettings.get())


@admin_bp.route("/reviews/<int:review_id>/approve", methods=["POST"])
def review_approve(review_id):
    r = Review.query.get_or_404(review_id)
    r.is_approved = not r.is_approved
    db.session.commit()
    flash("Статус отзыва обновлён.", "info")
    return redirect(url_for("admin.reviews_list"))


@admin_bp.route("/reviews/<int:review_id>/delete", methods=["POST"])
def review_delete(review_id):
    r = Review.query.get_or_404(review_id)
    db.session.delete(r)
    db.session.commit()
    flash("Отзыв удалён.", "info")
    return redirect(url_for("admin.reviews_list"))


# ===================== Messages =====================

@admin_bp.route("/messages")
def messages_list():
    messages = Message.query.order_by(Message.created_at.desc()).all()
    return render_template("admin/messages.html", messages=messages, settings=ShopSettings.get())


@admin_bp.route("/messages/<int:message_id>/read", methods=["POST"])
def message_read(message_id):
    msg = Message.query.get_or_404(message_id)
    msg.is_read = not msg.is_read
    db.session.commit()
    flash("Статус сообщения обновлён.", "info")
    return redirect(url_for("admin.messages_list"))


@admin_bp.route("/messages/<int:message_id>/delete", methods=["POST"])
def message_delete(message_id):
    msg = Message.query.get_or_404(message_id)
    db.session.delete(msg)
    db.session.commit()
    flash("Сообщение удалено.", "info")
    return redirect(url_for("admin.messages_list"))


# ===================== Settings =====================

@admin_bp.route("/settings", methods=["GET", "POST"])
def settings():
    s = ShopSettings.get()
    form = ShopSettingsForm(obj=s)
    if form.validate_on_submit():
        s.shop_name = form.shop_name.data.strip()
        s.tagline = (form.tagline.data or "").strip()
        s.phone = (form.phone.data or "").strip()
        s.email = (form.email.data or "").strip().lower()
        s.address = (form.address.data or "").strip()
        s.description = (form.description.data or "").strip()
        s.delivery_info = (form.delivery_info.data or "").strip()
        s.payment_info = (form.payment_info.data or "").strip()
        s.homepage_text = (form.homepage_text.data or "").strip()
        db.session.commit()
        flash("Настройки сохранены.", "success")
        return redirect(url_for("admin.settings"))
    return render_template("admin/settings.html", form=form, settings=s)
