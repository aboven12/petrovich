"""Auth routes: register, login, logout, email confirm, password reset."""
from datetime import datetime, timedelta

from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app, abort
from flask_login import login_user, logout_user, current_user, login_required

from app.extensions import db, limiter
from app.models.user import User, Role
from app.models.token import Token, TokenType
from app.routes.forms import (
    RegistrationForm,
    LoginForm,
    PasswordResetRequestForm,
    PasswordResetForm,
)
from app.services.mail_service import send_email_confirmation, send_password_reset


auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/register", methods=["GET", "POST"])
@limiter.limit("5 per minute;10 per hour")
def register():
    if current_user.is_authenticated:
        return redirect(url_for("main.index"))
    form = RegistrationForm()
    if form.validate_on_submit():
        user = User(
            name=form.name.data.strip(),
            email=form.email.data.strip().lower(),
            role=Role.CUSTOMER,
            email_confirmed=False,
        )
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()

        token = Token.generate(user.id, TokenType.EMAIL_CONFIRM, current_app.config["EMAIL_CONFIRM_TOKEN_MAX_AGE"])
        send_email_confirmation(user, token.value)
        flash("Аккаунт создан. Мы отправили ссылку для подтверждения email.", "success")
        return redirect(url_for("auth.login"))
    return render_template("auth/register.html", form=form)


@auth_bp.route("/login", methods=["GET", "POST"])
@limiter.limit("8 per minute;20 per hour")
def login():
    if current_user.is_authenticated:
        return redirect(url_for("main.index"))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter(db.func.lower(User.email) == form.email.data.strip().lower()).first()
        # Constant-time-ish: even if user doesn't exist, hash a dummy password
        if user is None:
            # dummy to slow enumeration
            from werkzeug.security import generate_password_hash, check_password_hash
            check_password_hash(generate_password_hash("dummy"), form.password.data)
            flash("Неверный email или пароль.", "error")
            return render_template("auth/login.html", form=form)

        # Lockout check
        if user.locked_until and user.locked_until > datetime.utcnow():
            flash("Слишком много попыток. Попробуйте позже.", "error")
            return render_template("auth/login.html", form=form)

        if not user.check_password(form.password.data):
            user.failed_login_attempts = (user.failed_login_attempts or 0) + 1
            if user.failed_login_attempts >= 5:
                user.locked_until = datetime.utcnow() + timedelta(minutes=15)
                user.failed_login_attempts = 0
            db.session.commit()
            flash("Неверный email или пароль.", "error")
            return render_template("auth/login.html", form=form)

        if not user.is_active_user:
            flash("Аккаунт заблокирован.", "error")
            return render_template("auth/login.html", form=form)

        user.failed_login_attempts = 0
        user.locked_until = None
        user.last_login_at = datetime.utcnow()
        db.session.commit()

        login_user(user, remember=form.remember.data)
        next_url = request.args.get("next") or url_for("main.index")
        # Strict next: only same-site relative paths, no protocol-relative URLs
        if not next_url.startswith("/") or next_url.startswith("//") or next_url.startswith("/\\"):
            next_url = url_for("main.index")
        flash(f"Привет, {user.name}!", "success")
        return redirect(next_url)
    return render_template("auth/login.html", form=form)


@auth_bp.route("/logout")
@login_required
def logout():
    logout_user()
    flash("Вы вышли из аккаунта.", "info")
    return redirect(url_for("main.index"))


@auth_bp.route("/confirm-email/<token>")
def confirm_email(token):
    tok = Token.consume(token, TokenType.EMAIL_CONFIRM)
    if not tok:
        flash("Ссылка недействительна или устарела.", "error")
        return redirect(url_for("auth.login"))
    user = User.query.get(tok.user_id)
    if not user:
        flash("Пользователь не найден.", "error")
        return redirect(url_for("auth.login"))
    user.email_confirmed = True
    db.session.commit()
    flash("Email подтверждён. Теперь вы можете войти.", "success")
    return redirect(url_for("auth.login"))


@auth_bp.route("/reset-password", methods=["GET", "POST"])
@limiter.limit("3 per minute;10 per hour")
def reset_password_request():
    if current_user.is_authenticated:
        return redirect(url_for("main.index"))
    form = PasswordResetRequestForm()
    if form.validate_on_submit():
        user = User.query.filter(db.func.lower(User.email) == form.email.data.strip().lower()).first()
        if user:
            # Invalidate prior reset tokens for this user
            Token.query.filter_by(user_id=user.id, type=TokenType.PASSWORD_RESET, used=False).update({"used": True})
            token = Token.generate(user.id, TokenType.PASSWORD_RESET, current_app.config["PASSWORD_RESET_TOKEN_MAX_AGE"])
            send_password_reset(user, token.value)
        # Always show the same message to prevent enumeration
        flash("Если email зарегистрирован — мы отправили ссылку для сброса пароля.", "info")
        return redirect(url_for("auth.login"))
    return render_template("auth/reset_request.html", form=form)


@auth_bp.route("/reset-password/<token>", methods=["GET", "POST"])
def reset_password(token):
    if current_user.is_authenticated:
        return redirect(url_for("main.index"))
    # Check token validity without consuming
    tok = Token.query.filter_by(value=token, type=TokenType.PASSWORD_RESET, used=False).first()
    if not tok or tok.expires_at < datetime.utcnow():
        flash("Ссылка недействительна или устарела.", "error")
        return redirect(url_for("auth.reset_password_request"))

    form = PasswordResetForm()
    if form.validate_on_submit():
        tok = Token.consume(token, TokenType.PASSWORD_RESET)
        if not tok:
            flash("Ссылка уже использована.", "error")
            return redirect(url_for("auth.reset_password_request"))
        user = User.query.get(tok.user_id)
        if not user:
            abort(404)
        user.set_password(form.password.data)
        db.session.commit()
        flash("Пароль обновлён. Войдите с новым паролем.", "success")
        return redirect(url_for("auth.login"))
    return render_template("auth/reset_confirm.html", form=form, token=token)
