"""Account routes: profile, orders, favorites, settings."""
from datetime import datetime

from flask import Blueprint, render_template, redirect, url_for, flash, request, abort, jsonify
from flask_login import current_user, login_required

from app.extensions import db
from app.models.order import Order, OrderStatus
from app.models.favorite import Favorite
from app.models.product import Product
from app.routes.forms import ProfileForm, PasswordChangeForm, ReviewForm
from app.services.orders import can_user_access_order


account_bp = Blueprint("account", __name__)


@account_bp.route("/")
@login_required
def index():
    return redirect(url_for("account.profile"))


@account_bp.route("/profile")
@login_required
def profile():
    settings_form = ProfileForm(obj=current_user)
    pwd_form = PasswordChangeForm()
    return render_template("account/profile.html", settings_form=settings_form, pwd_form=pwd_form)


@account_bp.route("/profile/update", methods=["POST"])
@login_required
def profile_update():
    form = ProfileForm()
    if form.validate_on_submit():
        current_user.name = form.name.data.strip()
        current_user.phone = (form.phone.data or "").strip() or None
        current_user.address = (form.address.data or "").strip() or None
        db.session.commit()
        flash("Профиль обновлён.", "success")
    else:
        for field, errs in form.errors.items():
            for e in errs:
                flash(f"{getattr(form[field], 'label', {}).text, field}: {e}", "error")
    return redirect(url_for("account.profile"))


@account_bp.route("/password", methods=["POST"])
@login_required
def password_change():
    form = PasswordChangeForm()
    if form.validate_on_submit():
        if not current_user.check_password(form.current.data):
            flash("Текущий пароль неверный.", "error")
        else:
            current_user.set_password(form.new.data)
            db.session.commit()
            flash("Пароль изменён.", "success")
    else:
        for field, errs in form.errors.items():
            for e in errs:
                flash(f"{field}: {e}", "error")
    return redirect(url_for("account.profile"))


@account_bp.route("/orders")
@login_required
def orders():
    page = request.args.get("page", 1, type=int)
    pagination = (
        Order.query
        .filter_by(user_id=current_user.id)
        .order_by(Order.created_at.desc())
        .paginate(page=page, per_page=10, error_out=False)
    )
    return render_template("account/orders.html", pagination=pagination, orders=pagination.items)


@account_bp.route("/orders/<int:order_id>")
@login_required
def order_detail(order_id):
    order = Order.query.get_or_404(order_id)
    if not can_user_access_order(current_user, order):
        abort(403)
    return render_template("account/order_detail.html", order=order)


@account_bp.route("/favorites")
@login_required
def favorites():
    return redirect(url_for("shop.favorites"))


@account_bp.route("/reviews", methods=["POST"])
@login_required
def add_review():
    form = ReviewForm()
    product_id = request.form.get("product_id", type=int)
    if not product_id:
        abort(400)
    prod = Product.query.filter_by(id=product_id, is_published=True).first_or_404()
    if form.validate_on_submit():
        from app.models.review import Review
        review = Review(
            product_id=product_id,
            user_id=current_user.id,
            author_name=current_user.name,
            rating=int(form.rating.data),
            text=form.text.data.strip(),
        )
        db.session.add(review)
        db.session.commit()
        # Update product rating
        from sqlalchemy import func
        avg = db.session.query(func.avg(Review.rating)).filter_by(product_id=product_id, is_approved=True).scalar()
        prod.rating = float(avg) if avg else 0
        db.session.commit()
        flash("Спасибо за отзыв!", "success")
    else:
        for field, errs in form.errors.items():
            for e in errs:
                flash(f"{field}: {e}", "error")
    return redirect(url_for("shop.product_detail", slug=prod.slug))
