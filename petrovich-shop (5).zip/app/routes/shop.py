"""Shop routes: catalog, product, cart, checkout."""
from decimal import Decimal

from flask import (
    Blueprint, render_template, redirect, url_for, flash, request,
    jsonify, current_app, abort, session,
)
from flask_login import current_user, login_required

from app.extensions import db
from app.models.product import Product, Category, Flavor, slugify
from app.models.order import Order, DeliveryMethod
from app.models.settings import ShopSettings
from app.routes.forms import CheckoutForm, ReviewForm
from app.services.cart import Cart
from app.services.orders import (
    create_order_from_cart,
    can_user_access_order,
    EmptyCartError,
    InsufficientStockError,
)


shop_bp = Blueprint("shop", __name__)


@shop_bp.route("/catalog")
def catalog():
    page = request.args.get("page", 1, type=int)
    per_page = 12

    q = Product.query.filter_by(is_published=True)

    # Filters
    category_slug = request.args.get("category")
    flavor_slug = request.args.get("flavor")
    search = (request.args.get("q") or "").strip()
    sort = request.args.get("sort", "popular")
    min_price = request.args.get("min_price", type=float)
    max_price = request.args.get("max_price", type=float)

    if category_slug:
        cat = Category.query.filter_by(slug=category_slug, is_active=True).first()
        if cat:
            q = q.filter(Product.category_id == cat.id)
    if flavor_slug:
        flavor = Flavor.query.filter_by(slug=flavor_slug).first()
        if flavor:
            q = q.filter(Product.flavors.contains(flavor))
    if search:
        like = f"%{search}%"
        q = q.filter(
            db.or_(Product.name.ilike(like), Product.description.ilike(like), Product.taste.ilike(like))
        )
    if min_price is not None:
        q = q.filter(Product.price >= min_price)
    if max_price is not None:
        q = q.filter(Product.price <= max_price)

    if sort == "price_asc":
        q = q.order_by(Product.price.asc())
    elif sort == "price_desc":
        q = q.order_by(Product.price.desc())
    elif sort == "new":
        q = q.order_by(Product.created_at.desc())
    else:  # popular
        q = q.order_by(Product.is_popular.desc(), Product.rating.desc(), Product.created_at.desc())

    pagination = q.paginate(page=page, per_page=per_page, error_out=False)
    categories = Category.query.filter_by(is_active=True).all()
    flavors = Flavor.query.order_by(Flavor.name).all()
    settings = ShopSettings.get()

    return render_template(
        "shop/catalog.html",
        products=pagination.items,
        pagination=pagination,
        categories=categories,
        flavors=flavors,
        selected_category=category_slug or "",
        selected_flavor=flavor_slug or "",
        search=search,
        sort=sort,
        min_price=min_price,
        max_price=max_price,
        settings=settings,
    )


@shop_bp.route("/product/<slug>")
def product_detail(slug):
    prod = Product.query.filter_by(slug=slug, is_published=True).first_or_404()
    related = (
        Product.query.filter(
            Product.is_published == True,
            Product.id != prod.id,
            Product.category_id == prod.category_id,
        )
        .order_by(Product.rating.desc())
        .limit(4)
        .all()
    ) if prod.category_id else []
    if len(related) < 4:
        extra = Product.query.filter(
            Product.is_published == True,
            Product.id != prod.id,
        ).order_by(Product.rating.desc()).limit(4 - len(related)).all()
        related += extra
    review_form = ReviewForm()
    from app.models.review import Review
    reviews = Review.query.filter_by(product_id=prod.id, is_approved=True).order_by(Review.created_at.desc()).limit(10).all()
    settings = ShopSettings.get()
    return render_template(
        "shop/product.html",
        product=prod,
        related=related,
        reviews=reviews,
        review_form=review_form,
        settings=settings,
    )


@shop_bp.route("/cart")
def cart_view():
    cart = Cart.current()
    info = cart.detailed()
    settings = ShopSettings.get()
    return render_template("shop/cart.html", cart_info=info, settings=settings)


@shop_bp.route("/cart/add", methods=["POST"])
def cart_add():
    product_id = request.form.get("product_id", type=int)
    qty = request.form.get("qty", 1, type=int)
    if not product_id:
        abort(404)
    prod = Product.query.filter_by(id=product_id, is_published=True).first_or_404()
    if prod.stock <= 0:
        if request.is_json or request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return jsonify({"ok": False, "error": "Товара нет в наличии"}), 400
        flash("Товара нет в наличии", "error")
        return redirect(url_for("shop.product_detail", slug=prod.slug))
    cart = Cart.current()
    added = cart.add(product_id, qty)
    if request.is_json or request.headers.get("X-Requested-With") == "XMLHttpRequest":
        return jsonify({"ok": True, "qty": added, "cart_count": cart.total_items, "cart_total": str(cart.detailed().total)})
    flash(f"«{prod.name}» добавлен в корзину (x{added}).", "success")
    return redirect(request.referrer or url_for("shop.cart_view"))


@shop_bp.route("/cart/update", methods=["POST"])
def cart_update():
    product_id = request.form.get("product_id", type=int)
    qty = request.form.get("qty", type=int)
    if not product_id or qty is None:
        abort(400)
    cart = Cart.current()
    new_qty = cart.set_qty(product_id, qty)
    info = cart.detailed()
    # Per-line total for this product
    line_total = None
    for item in info.items:
        if item["product"].id == product_id:
            line_total = float(item["line_total"])
            break
    if request.is_json or request.headers.get("X-Requested-With") == "XMLHttpRequest":
        return jsonify({
            "ok": True,
            "qty": new_qty,
            "cart_count": cart.total_items,
            "line_total": ("%.0f" % line_total) if line_total is not None else "0",
            "items_total": "%.0f" % float(info.items_total),
            "total": "%.0f" % float(info.total),
        })
    return redirect(url_for("shop.cart_view"))


@shop_bp.route("/cart/remove", methods=["POST"])
def cart_remove():
    product_id = request.form.get("product_id", type=int)
    if not product_id:
        abort(400)
    cart = Cart.current()
    cart.remove(product_id)
    if request.is_json or request.headers.get("X-Requested-With") == "XMLHttpRequest":
        info = cart.detailed()
        return jsonify({
            "ok": True,
            "cart_count": cart.total_items,
            "items_total": str(info.items_total),
            "total": str(info.total),
        })
    return redirect(url_for("shop.cart_view"))


@shop_bp.route("/cart/clear", methods=["POST"])
def cart_clear():
    Cart.current().clear()
    if request.is_json or request.headers.get("X-Requested-With") == "XMLHttpRequest":
        return jsonify({"ok": True, "cart_count": 0})
    return redirect(url_for("shop.cart_view"))


@shop_bp.route("/checkout", methods=["GET", "POST"])
def checkout():
    """Оформление заказа. Доступно и без регистрации (гостевой заказ)."""
    cart = Cart.current()
    info = cart.detailed()
    if info.count == 0:
        flash("Корзина пуста.", "info")
        return redirect(url_for("shop.catalog"))

    form = CheckoutForm()
    is_logged = current_user.is_authenticated

    if request.method == "GET":
        if is_logged:
            form.contact_name.data = current_user.name
            form.contact_phone.data = current_user.phone or ""
            form.contact_email.data = current_user.email
            form.address.data = current_user.address or ""
        form.delivery_method.data = "pickup"

    delivery_cost = Decimal("0")
    if form.delivery_method.data == "courier":
        delivery_cost = Decimal("25")
    total = info.items_total + delivery_cost

    if form.validate_on_submit():
        delivery_method = DeliveryMethod(form.delivery_method.data)
        try:
            order = create_order_from_cart(
                cart,
                user=current_user if is_logged else None,
                contact_name=form.contact_name.data.strip(),
                contact_phone=form.contact_phone.data.strip(),
                contact_email=(form.contact_email.data or "").strip() or None,
                address=(form.address.data or "").strip() or None,
                comment=(form.comment.data or "").strip() or None,
                delivery_method=delivery_method,
            )
            # Запоминаем номер в сессии — доступ гостя к странице успеха
            session["last_order_number"] = order.number
            flash(f"Заказ {order.number} оформлен! Мы позвоним для подтверждения.", "success")
            return redirect(url_for("shop.order_success", order_number=order.number))
        except EmptyCartError:
            flash("Корзина пуста.", "error")
            return redirect(url_for("shop.catalog"))
        except InsufficientStockError as e:
            flash(str(e), "error")
            return redirect(url_for("shop.cart_view"))

    settings = ShopSettings.get()
    return render_template(
        "shop/checkout.html",
        form=form,
        cart_info=info,
        delivery_cost=delivery_cost,
        total=total,
        settings=settings,
    )


@shop_bp.route("/order-success/<order_number>")
def order_success(order_number):
    """Страница успешного заказа. Доступ: свежий заказ из сессии или владелец."""
    order = Order.query.filter_by(number=order_number).first_or_404()
    allowed = (
        session.get("last_order_number") == order.number
        or (current_user.is_authenticated and can_user_access_order(current_user, order))
    )
    if not allowed:
        abort(404)
    settings = ShopSettings.get()
    return render_template("shop/order_success.html", order=order, settings=settings)


@shop_bp.route("/favorites")
@login_required
def favorites():
    from app.models.favorite import Favorite
    favs = (
        Favorite.query
        .filter_by(user_id=current_user.id)
        .join(Product)
        .filter(Product.is_published == True)
        .order_by(Favorite.created_at.desc())
        .all()
    )
    settings = ShopSettings.get()
    return render_template("shop/favorites.html", favorites=favs, settings=settings)
