/* PETROVICH main JS: toasts, reveal-on-scroll, menus, cart, favorites */

(function () {
  'use strict';

  const SPRITE = '/static/images/icons/sprite.svg';

  // ---------- Toast helpers ----------
  function showToast(msg, type) {
    let container = document.getElementById('toast-container');
    if (!container) {
      container = document.createElement('div');
      container.className = 'toast-container';
      container.id = 'toast-container';
      document.body.appendChild(container);
    }
    const t = document.createElement('div');
    t.className = 'toast ' + (type || 'info');
    t.textContent = msg;
    container.appendChild(t);
    setTimeout(() => {
      t.style.opacity = '0';
      t.style.transform = 'translateX(30px)';
      t.style.transition = 'all .35s ease';
      setTimeout(() => t.remove(), 380);
    }, 3500);
  }

  function setupToasts() {
    const container = document.getElementById('toast-container');
    if (!container) return;
    container.querySelectorAll('.toast').forEach(t => {
      setTimeout(() => {
        t.style.opacity = '0';
        t.style.transform = 'translateX(30px)';
        t.style.transition = 'all .35s ease';
        setTimeout(() => t.remove(), 380);
      }, 4500);
    });
  }

  // ---------- Reveal on scroll ----------
  function setupReveal() {
    const els = document.querySelectorAll('.reveal');
    if (!els.length) return;
    if (!('IntersectionObserver' in window)) {
      els.forEach(e => e.classList.add('in'));
      return;
    }
    const obs = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in');
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08, rootMargin: '0px 0px -40px 0px' });
    els.forEach(e => obs.observe(e));
  }

  // ---------- Mobile menu ----------
  function setupMobileMenu() {
    const btn = document.getElementById('menu-toggle');
    const nav = document.getElementById('main-nav');
    if (!btn || !nav) return;
    btn.addEventListener('click', () => nav.classList.toggle('open'));
    nav.querySelectorAll('a').forEach(a => {
      a.addEventListener('click', () => nav.classList.remove('open'));
    });
  }

  // ---------- Admin mobile menu ----------
  function setupAdminMenu() {
    const btn = document.getElementById('admin-toggle');
    const side = document.getElementById('admin-sidebar');
    if (!btn || !side) return;
    btn.addEventListener('click', e => {
      e.stopPropagation();
      side.classList.toggle('open');
    });
    document.addEventListener('click', e => {
      if (!side.contains(e.target) && e.target !== btn) side.classList.remove('open');
    });
  }

  // ---------- FAQ accordion ----------
  function setupFAQ() {
    document.querySelectorAll('.faq-q').forEach(q => {
      q.addEventListener('click', () => {
        const item = q.closest('.faq-item');
        const wasOpen = item.classList.contains('open');
        document.querySelectorAll('.faq-item').forEach(i => i.classList.remove('open'));
        if (!wasOpen) item.classList.add('open');
      });
    });
  }

  // ---------- Cart count badge ----------
  function updateCartCount() {
    const el = document.getElementById('cart-count');
    if (!el) return;
    fetch('/api/cart/count', { credentials: 'same-origin' })
      .then(r => r.json())
      .then(data => {
        if (data && typeof data.count !== 'undefined') {
          el.textContent = data.count > 0 ? data.count : '';
        }
      })
      .catch(() => {});
  }

  // ---------- Add-to-cart via AJAX ----------
  function setupAddToCart() {
    document.body.addEventListener('submit', async (e) => {
      const form = e.target;
      if (!form.classList.contains('js-add-to-cart')) return;
      e.preventDefault();
      const btn = form.querySelector('[type=submit]');
      if (btn) btn.disabled = true;
      try {
        const resp = await fetch(form.action, {
          method: 'POST',
          body: new FormData(form),
          credentials: 'same-origin',
          headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const data = await resp.json();
        if (data.ok) {
          showToast('Добавлено в корзину', 'success');
          updateCartCount();
        } else {
          showToast(data.error || 'Не удалось добавить товар', 'error');
        }
      } catch (err) {
        showToast('Проверьте соединение и попробуйте ещё раз', 'error');
      } finally {
        if (btn) btn.disabled = false;
      }
    });
  }

  // ---------- Favorites ----------
  function setupFavorites() {
    document.body.addEventListener('click', async (e) => {
      const btn = e.target.closest('[data-fav-toggle]');
      if (!btn) return;
      e.preventDefault();
      const pid = btn.dataset.productId;
      const form = new FormData();
      form.append('product_id', pid);
      form.append('csrf_token', window.CSRF_TOKEN);
      try {
        const resp = await fetch('/api/favorite/toggle', {
          method: 'POST',
          body: form,
          credentials: 'same-origin',
        });
        const data = await resp.json();
        if (data.ok) {
          document.querySelectorAll('[data-fav-toggle][data-product-id="' + pid + '"]').forEach(b => {
            b.classList.toggle('is-fav', data.is_favorite);
            const use = b.querySelector('use');
            if (use) {
              use.setAttribute('href',
                data.is_favorite ? SPRITE + '#heart-filled' : SPRITE + '#heart');
            }
          });
          showToast(data.is_favorite ? 'Добавлено в избранное' : 'Убрано из избранного', 'info');
        } else {
          showToast(data.error || 'Ошибка', 'error');
        }
      } catch (err) {
        showToast('Не удалось обновить избранное', 'error');
      }
    });
  }

  // ---------- Cart page: quantity steppers ----------
  function fmtMoney(v) {
    const n = parseFloat(String(v).replace(',', '.'));
    return (isNaN(n) ? 0 : Math.round(n)) + ' ₽';
  }

  function refreshCartTotals(data) {
    if (!data) return;
    document.querySelectorAll('[data-items-total]').forEach(el => el.textContent = fmtMoney(data.items_total));
    document.querySelectorAll('[data-cart-total]').forEach(el => el.textContent = fmtMoney(data.total));
    const badge = document.getElementById('cart-count');
    if (badge) badge.textContent = data.cart_count > 0 ? data.cart_count : '';
  }

  async function updateQty(pid, qty) {
    const form = new FormData();
    form.append('product_id', pid);
    form.append('qty', qty);
    form.append('csrf_token', window.CSRF_TOKEN);
    try {
      const resp = await fetch('/cart/update', {
        method: 'POST',
        body: form,
        credentials: 'same-origin',
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
      });
      const data = await resp.json();
      if (data.ok) {
        // Update this row's line total
        const row = document.querySelector('[data-cart-item][data-product-id="' + pid + '"]');
        if (row) {
          const lt = row.querySelector('[data-line-total]');
          if (lt && data.line_total !== undefined) lt.textContent = fmtMoney(data.line_total);
        }
        refreshCartTotals(data);
        if (data.cart_count === 0) window.location.reload();
      } else {
        showToast(data.error || 'Ошибка', 'error');
      }
    } catch (err) {
      showToast('Не удалось обновить количество', 'error');
    }
  }

  function setupCartQty() {
    document.querySelectorAll('[data-qty-block]').forEach(block => {
      const input = block.querySelector('[data-qty-input]');
      const dec = block.querySelector('[data-qty-dec]');
      const inc = block.querySelector('[data-qty-inc]');
      const pid = block.dataset.productId;
      const max = parseInt(block.dataset.max) || 99;
      if (dec) dec.addEventListener('click', () => {
        const v = Math.max(1, parseInt(input.value || 1) - 1);
        input.value = v;
        updateQty(pid, v);
      });
      if (inc) inc.addEventListener('click', () => {
        const v = Math.min(max, parseInt(input.value || 1) + 1);
        input.value = v;
        updateQty(pid, v);
      });
      if (input) input.addEventListener('change', () => {
        let v = parseInt(input.value) || 1;
        v = Math.max(1, Math.min(max, v));
        input.value = v;
        updateQty(pid, v);
      });
    });
  }

  // ---------- Account tabs ----------
  function setupTabs() {
    document.querySelectorAll('.tab-link').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.tab-link').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        document.querySelectorAll('[data-tab-content]').forEach(c => c.classList.add('hidden'));
        const target = document.querySelector('[data-tab-content="' + btn.dataset.tab + '"]');
        if (target) target.classList.remove('hidden');
      });
    });
  }

  // ---------- Init ----------
  document.addEventListener('DOMContentLoaded', () => {
    setupToasts();
    setupReveal();
    setupMobileMenu();
    setupAdminMenu();
    setupFAQ();
    setupAddToCart();
    setupFavorites();
    setupCartQty();
    setupTabs();
    updateCartCount();
  });

  window.PETROVICH = { showToast, updateCartCount };
})();
