"""Error handlers."""
from flask import render_template, request, jsonify


def register_error_handlers(app):
    @app.errorhandler(400)
    def bad_request(e):
        if request.is_json or request.path.startswith("/api/"):
            return jsonify({"error": "Bad request"}), 400
        return render_template("errors/400.html"), 400

    @app.errorhandler(401)
    def unauthorized(e):
        if request.is_json or request.path.startswith("/api/"):
            return jsonify({"error": "Unauthorized"}), 401
        return render_template("errors/401.html"), 401

    @app.errorhandler(403)
    def forbidden(e):
        if request.is_json or request.path.startswith("/api/"):
            return jsonify({"error": "Forbidden"}), 403
        return render_template("errors/403.html"), 403

    @app.errorhandler(404)
    def not_found(e):
        if request.is_json or request.path.startswith("/api/"):
            return jsonify({"error": "Not found"}), 404
        return render_template("errors/404.html"), 404

    @app.errorhandler(413)
    def too_large(e):
        return render_template("errors/413.html"), 413

    @app.errorhandler(429)
    def rate_limited(e):
        if request.is_json or request.path.startswith("/api/"):
            return jsonify({"error": "Too many requests"}), 429
        return render_template("errors/429.html"), 429

    @app.errorhandler(500)
    def server_error(e):
        # Don't leak traceback
        if request.is_json or request.path.startswith("/api/"):
            return jsonify({"error": "Internal server error"}), 500
        try:
            return render_template("errors/500.html"), 500
        except Exception:
            return "Internal server error", 500
