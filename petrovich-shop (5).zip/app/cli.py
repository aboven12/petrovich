"""Flask CLI commands: init-db, init-admin, seed, run-tests."""
import click
import secrets

from flask import current_app
from flask.cli import AppGroup

from app.extensions import db
from app.models.user import User, Role
from app.models.product import Product, Category, Flavor, slugify
from app.models.settings import ShopSettings
from app.models.review import Review


cli = AppGroup("petrovich")


def register_cli(app):
    app.cli.add_command(cli)


def ensure_admin_exists() -> None:
    """Create or UPDATE the admin account from env vars on every startup.

    The .env file is the source of truth for admin credentials: if you change
    ADMIN_EMAIL / ADMIN_PASSWORD and restart the app, the database row is
    updated to match. This way the owner can always reset a forgotten admin
    password simply by editing .env and restarting — no CLI needed."""
    try:
        email = (current_app.config.get("ADMIN_EMAIL") or "").strip().lower()
        password = current_app.config.get("ADMIN_PASSWORD")
        if not email or not password or len(password) < 8:
            return

        existing = User.query.filter_by(email=email).first()
        if existing:
            # Always sync role + password from .env so the env file stays
            # the single source of truth for the admin login.
            changed = False
            if existing.role != Role.ADMIN:
                existing.role = Role.ADMIN
                changed = True
            if not existing.email_confirmed:
                existing.email_confirmed = True
                changed = True
            if not existing.is_active_user:
                existing.is_active_user = True
                changed = True
            # Always re-set the password from env (idempotent, cheap enough
            # at startup). check_password_hash is used to skip the write if
            # the password already matches, avoiding needless churn.
            from werkzeug.security import check_password_hash
            if not check_password_hash(existing.password_hash or "", password):
                existing.set_password(password)
                changed = True
            # Clear any login lockout so the owner can log in right away
            # after fixing the password in .env.
            if existing.locked_until is not None or existing.failed_login_attempts:
                existing.locked_until = None
                existing.failed_login_attempts = 0
                changed = True
            if changed:
                db.session.commit()
            return

        admin = User(
            name="Администратор",
            email=email,
            role=Role.ADMIN,
            email_confirmed=True,
            is_active_user=True,
        )
        admin.set_password(password)
        db.session.add(admin)
        db.session.commit()
    except Exception:
        db.session.rollback()


@cli.command("init-db")
def init_db():
    """Create all tables."""
    with current_app.app_context():
        db.create_all()
        ShopSettings.get()
        click.echo("Database initialized.")


@cli.command("init-admin")
def init_admin():
    """Create the initial administrator from env vars.
    Idempotent: reuses an existing admin if email matches."""
    # Try to load .env from the current directory
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except Exception:
        pass

    import os as _os
    with current_app.app_context():
        email = (current_app.config.get("ADMIN_EMAIL") or _os.environ.get("ADMIN_EMAIL") or "").strip().lower()
        password = current_app.config.get("ADMIN_PASSWORD") or _os.environ.get("ADMIN_PASSWORD")
        if not email or not password:
            click.echo("")
            click.echo("ERROR: ADMIN_EMAIL and ADMIN_PASSWORD are not set.")
            click.echo("")
            click.echo("Fix: open the .env file in the project folder and fill in:")
            click.echo("  ADMIN_EMAIL=your@email.com")
            click.echo("  ADMIN_PASSWORD=YourStrongPassword123")
            click.echo("")
            click.echo("The .env file must be at: C:\\Users\\barmaley\\Desktop\\petrovich\\.env")
            click.echo("")
            raise click.Abort()
        if len(password) < 8:
            click.echo("ADMIN_PASSWORD must be at least 8 chars.")
            raise click.Abort()

        existing = User.query.filter_by(email=email).first()
        if existing:
            if existing.role != Role.ADMIN:
                existing.role = Role.ADMIN
            existing.set_password(password)
            existing.email_confirmed = True
            existing.is_active_user = True
            db.session.commit()
            click.echo(f"Admin updated: {email}")
        else:
            admin = User(
                name="Администратор",
                email=email,
                role=Role.ADMIN,
                email_confirmed=True,
                is_active_user=True,
            )
            admin.set_password(password)
            db.session.add(admin)
            db.session.commit()
            click.echo(f"Admin created: {email}")
        click.echo("You can now log in via /auth/login.")


@cli.command("seed")
def seed():
    """Seed demo data: categories, flavors, products."""
    with current_app.app_context():
        ShopSettings.get()

        # Categories
        cat_data = [
            ("Фруктовый", "Яркие фруктовые вкусы: апельсин, лимон, манго, ананас."),
            ("Ягодный", "Сочные ягоды: клубника, малина, вишня, черника."),
            ("Кислый", "Подкислённые вкусы для любителей поярче."),
            ("Сладкий", "Десертные сладкие вкусы с мёдом и карамелью."),
            ("Ассорти", "Наборы разных вкусов в одной коробке."),
            ("Новинки", "Самое свежее и экспериментальное."),
        ]
        cats = {}
        for name, desc in cat_data:
            c = Category.query.filter_by(slug=slugify(name)).first()
            if not c:
                c = Category(name=name, slug=slugify(name), description=desc, is_active=True)
                db.session.add(c)
                db.session.flush()
            cats[name] = c

        # Flavors
        flavor_data = [
            ("Клубника", "#E63E3E", "Сочная садовая клубника."),
            ("Малина", "#D81B60", "Лесная малина, тёплая и сладкая."),
            ("Манго", "#FF9800", "Тропический манго с медовой нотой."),
            ("Апельсин", "#FF6F00", "Цитрусовый взрыв, как свежевыжатый сок."),
            ("Лимон", "#FBC02D", "Бодрящий лимон с кислинкой."),
            ("Черника", "#3F51B5", "Глубокая черничная ягода."),
            ("Вишня", "#880E4F", "Тёмная вишня с лёгкой кислинкой."),
            ("Арбуз", "#E91E63", "Свежий арбуз, вкус лета."),
            ("Ананас", "#FFC107", "Сладкий ананас с кислинкой."),
            ("Ассорти", "#7C4DFF", "Сразу несколько вкусов в одной коробке."),
        ]
        flavors = {}
        for name, color, desc in flavor_data:
            f = Flavor.query.filter_by(slug=slugify(name)).first()
            if not f:
                f = Flavor(name=name, slug=slugify(name), description=desc, color_hex=color)
                db.session.add(f)
                db.session.flush()
            flavors[name] = f

        # Products
        product_data = [
            ("Апельсиновый мармелад", "Фруктовый", ["Апельсин"], 250, 480, True, False,
             "Яркий цитрусовый мармелад на основе свежего апельсинового сока и агар-агара.",
             "Агар-агар, сахар, апельсиновый сок, патока, лимонная кислота.",
             "Апельсин, цитрус, медовая нота"),
            ("Клубничный мармелад", "Ягодный", ["Клубника"], 250, 520, True, False,
             "Сочная садовая клубника в каждом кусочке.",
             "Агар-агар, сахар, клубничное пюре, патока, лимонная кислота.",
             "Сладкая клубника"),
            ("Малиновый мармелад", "Ягодный", ["Малина"], 250, 540, False, False,
             "Лесная малина, тёплая и ароматная.",
             "Агар-агар, сахар, малиновое пюре, патока, лимонная кислота.",
             "Малина с лёгкой кислинкой"),
            ("Лимонный мармелад", "Кислый", ["Лимон"], 250, 460, False, False,
             "Бодрящий лимон с ярким вкусом.",
             "Агар-агар, сахар, лимонный сок, патока, лимонная кислота.",
             "Кислый лимон, освежающий"),
            ("Черничный мармелад", "Ягодный", ["Черника"], 250, 580, False, True,
             "Глубокий черничный вкус с лёгкой терпкостью.",
             "Агар-агар, сахар, черничное пюре, патока, лимонная кислота.",
             "Черника, насыщенный ягодный"),
            ("Манговый мармелад", "Фруктовый", ["Манго"], 250, 620, False, True,
             "Тропический манго с медовым послевкусием.",
             "Агар-агар, сахар, манговое пюре, патока, лимонная кислота.",
             "Сладкий манго, тропик"),
            ("Вишнёвый мармелад", "Ягодный", ["Вишня"], 250, 540, False, False,
             "Тёмная вишня с лёгкой кислинкой.",
             "Агар-агар, сахар, вишнёвое пюре, патока, лимонная кислота.",
             "Вишня, кисло-сладкий"),
            ("Арбузный мармелад", "Фруктовый", ["Арбуз"], 250, 490, False, True,
             "Свежий арбуз — вкус лета в каждом кусочке.",
             "Агар-агар, сахар, арбузный сок, патока, лимонная кислота.",
             "Арбуз, лёгкий, свежий"),
            ("Ананасовый мармелад", "Фруктовый", ["Ананас"], 250, 560, False, False,
             "Сладкий ананас с тонкой кислинкой.",
             "Агар-агар, сахар, ананасовый сок, патока, лимонная кислота.",
             "Ананас, тропик, кислинка"),
            ("Ассорти «Лето»", "Ассорти", ["Ассорти"], 500, 980, False, False,
             "Шесть вкусов в одной коробке: клубника, малина, апельсин, лимон, черника, манго.",
             "Агар-агар, сахар, фруктово-ягодные пюре, патока, лимонная кислота.",
             "Микс вкусов, сладкий, ягодный"),
            ("Ассорти «Тропики»", "Ассорти", ["Ассорти"], 500, 1050, False, True,
             "Тропический микс: манго, ананас, апельсин, арбуз.",
             "Агар-агар, сахар, фруктовые пюре, патока, лимонная кислота.",
             "Тропик, манго, ананас, освежающий"),
            ("Микс «Сладкоежка»", "Сладкий", ["Клубника", "Малина"], 400, 820, True, False,
             "Десертный набор сладких ягод для любителей мёда и карамели.",
             "Агар-агар, сахар, ягодные пюре, мёд, патока, лимонная кислота.",
             "Сладкий, мёд, ягода"),
        ]

        # Build slug map for demo products (Cyrillic -> latin slug for nicer URLs)
        slug_map = {
            "Апельсиновый мармелад": "apelsinovyj-marmelad",
            "Клубничный мармелад": "klubnichnyj-marmelad",
            "Малиновый мармелад": "malinovyj-marmelad",
            "Лимонный мармелад": "limonnyj-marmelad",
            "Черничный мармелад": "chernichnyj-marmelad",
            "Манговый мармелад": "mangovyj-marmelad",
            "Вишнёвый мармелад": "vishnevyj-marmelad",
            "Арбузный мармелад": "arbuznyj-marmelad",
            "Ананасовый мармелад": "ananasovyj-marmelad",
            "Ассорти «Лето»": "assorti-leto",
            "Ассорти «Тропики»": "assorti-tropiki",
            "Микс «Сладкоежка»": "miks-sladkoezhka",
        }

        for name, cat_name, flavs, weight, price, popular, is_new, desc, comp, taste in product_data:
            slug = slug_map.get(name) or slugify(name)
            # Ensure unique
            existing = Product.query.filter_by(slug=slug).first()
            if existing:
                continue
            prod = Product(
                name=name,
                slug=slug,
                description=desc,
                composition=comp,
                taste=taste,
                weight_g=weight,
                price=price,
                shelf_life_days=10,
                stock=50,
                is_published=True,
                is_popular=popular,
                is_new=is_new,
                category_id=cats[cat_name].id,
                image=None,
            )
            db.session.add(prod)
            db.session.flush()
            for fn in flavs:
                if fn in flavors:
                    prod.flavors.append(flavors[fn])

        # Demo reviews
        if Review.query.count() == 0:
            sample_reviews = [
                (1, "Анна", 5, "Очень вкусный мармелад, не приторный! Беру уже третий раз."),
                (1, "Михаил", 5, "Лучший мармелад, что я пробовал. Текстура — огонь."),
                (2, "Ольга", 4, "Вкусно, но хотелось бы чуть поменьше сахара."),
                (3, "Дмитрий", 5, "Малина чувствуется на 100%, рекомендую."),
                (10, "Елена", 5, "Брала ассорти на день рождения — все в восторге!"),
            ]
            for prod_id, author, rating, text in sample_reviews:
                r = Review(product_id=prod_id, author_name=author, rating=rating, text=text, is_approved=True)
                db.session.add(r)

        db.session.commit()
        click.echo("Seed completed.")
