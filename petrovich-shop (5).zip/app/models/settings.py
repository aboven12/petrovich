"""Shop-wide settings (singleton row)."""
from app.extensions import db


class ShopSettings(db.Model):
    __tablename__ = "shop_settings"

    id = db.Column(db.Integer, primary_key=True, default=1)
    shop_name = db.Column(db.String(120), default="ПЕТРОВИЧ", nullable=False)
    tagline = db.Column(db.String(255), default="Домашний мармелад ручной работы", nullable=False)
    phone = db.Column(db.String(40), default="+7 900 000-00-00", nullable=False)
    email = db.Column(db.String(180), default="siluetorg@gmail.com", nullable=False)
    address = db.Column(db.Text, default="г. Новокузнецк, Кемеровская область", nullable=False)
    description = db.Column(db.Text, default="Домашний мармелад ручной работы из натуральных ингредиентов.", nullable=False)
    delivery_info = db.Column(db.Text, default="Самовывоз — бесплатно. Доставка по Новокузнецку — 25 ₽.", nullable=False)
    payment_info = db.Column(db.Text, default="Оплата наличными или картой при получении.", nullable=False)
    homepage_text = db.Column(db.Text, default="Варим мармелад сами: агар, фруктовые соки и мёд, без консервантов. Каждый вкус — маленькая история с нашей кухни в Новокузнецке.", nullable=False)

    @classmethod
    def get(cls) -> "ShopSettings":
        s = cls.query.first()
        if s is None:
            s = cls(id=1)
            db.session.add(s)
            db.session.commit()
        return s
