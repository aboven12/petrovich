"""Tokens for email confirmation and password reset."""
import secrets
from datetime import datetime, timedelta

from sqlalchemy import Enum as SAEnum
from enum import Enum

from app.extensions import db


class TokenType(Enum):
    EMAIL_CONFIRM = "email_confirm"
    PASSWORD_RESET = "password_reset"


class Token(db.Model):
    __tablename__ = "tokens"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    type = db.Column(SAEnum(TokenType), nullable=False, index=True)
    value = db.Column(db.String(64), unique=True, nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    expires_at = db.Column(db.DateTime, nullable=False)
    used = db.Column(db.Boolean, default=False, nullable=False)

    @classmethod
    def generate(cls, user_id: int, token_type: TokenType, ttl_seconds: int) -> "Token":
        """Create a new secure token."""
        token = cls(
            user_id=user_id,
            type=token_type,
            value=secrets.token_urlsafe(32),
            expires_at=datetime.utcnow() + timedelta(seconds=ttl_seconds),
        )
        db.session.add(token)
        db.session.commit()
        return token

    @classmethod
    def consume(cls, value: str, token_type: TokenType) -> "Token | None":
        """Validate and consume a token. Returns None if invalid/expired/used."""
        if not value:
            return None
        token = cls.query.filter_by(value=value, type=token_type, used=False).first()
        if not token:
            return None
        if token.expires_at < datetime.utcnow():
            return None
        token.used = True
        db.session.commit()
        return token

    @classmethod
    def cleanup_expired(cls) -> int:
        """Remove expired tokens. Returns count deleted."""
        cutoff = datetime.utcnow()
        expired = cls.query.filter(cls.expires_at < cutoff).all()
        for t in expired:
            db.session.delete(t)
        db.session.commit()
        return len(expired)
