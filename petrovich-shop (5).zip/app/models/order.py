"""Order and OrderItem models."""
from decimal import Decimal
from enum import Enum
from datetime import datetime

from sqlalchemy import Enum as SAEnum

from app.extensions import db


class OrderStatus(Enum):
    NEW = "new"
    CONFIRMED = "confirmed"
    COOKING = "cooking"
    READY = "ready"
    HANDED = "handed"
    COMPLETED = "completed"
    CANCELLED = "cancelled"

    @property
    def label(self) -> str:
        return {
            OrderStatus.NEW: "Новый",
            OrderStatus.CONFIRMED: "Подтверждён",
            OrderStatus.COOKING: "Готовится",
            OrderStatus.READY: "Готов к выдаче",
            OrderStatus.HANDED: "Передан покупателю",
            OrderStatus.COMPLETED: "Завершён",
            OrderStatus.CANCELLED: "Отменён",
        }[self]


class DeliveryMethod(Enum):
    PICKUP = "pickup"
    COURIER = "courier"

    @property
    def label(self) -> str:
        return {
            DeliveryMethod.PICKUP: "Самовывоз (бесплатно)",
            DeliveryMethod.COURIER: "Доставка по Новокузнецку (25 ₽)",
        }[self]


class Order(db.Model):
    __tablename__ = "orders"

    id = db.Column(db.Integer, primary_key=True)
    number = db.Column(db.String(20), unique=True, nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True, index=True)
    guest_name = db.Column(db.String(120), nullable=True)
    guest_email = db.Column(db.String(180), nullable=True)
    guest_phone = db.Column(db.String(40), nullable=True)

    contact_name = db.Column(db.String(120), nullable=False)
    contact_phone = db.Column(db.String(40), nullable=False)
    contact_email = db.Column(db.String(180), nullable=True)
    address = db.Column(db.Text, nullable=True)
    comment = db.Column(db.Text, nullable=True)

    delivery_method = db.Column(SAEnum(DeliveryMethod), default=DeliveryMethod.PICKUP, nullable=False)
    status = db.Column(SAEnum(OrderStatus), default=OrderStatus.NEW, nullable=False, index=True)

    items_total = db.Column(db.Numeric(10, 2), default=0, nullable=False)
    delivery_cost = db.Column(db.Numeric(10, 2), default=0, nullable=False)
    total = db.Column(db.Numeric(10, 2), default=0, nullable=False)

    admin_comment = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False, index=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    items = db.relationship("OrderItem", backref="order", cascade="all, delete-orphan", lazy="joined")

    @property
    def total_decimal(self) -> Decimal:
        return Decimal(self.total or 0)

    def __repr__(self):
        return f"<Order {self.number} {self.status.value}>"


class OrderItem(db.Model):
    __tablename__ = "order_items"

    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey("orders.id"), nullable=False, index=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=True)
    product_name = db.Column(db.String(160), nullable=False)
    product_price = db.Column(db.Numeric(10, 2), nullable=False)
    quantity = db.Column(db.Integer, nullable=False, default=1)
    line_total = db.Column(db.Numeric(10, 2), nullable=False, default=0)

    def __repr__(self):
        return f"<OrderItem {self.product_name} x{self.quantity}>"
