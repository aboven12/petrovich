"""User model with roles and password hashing."""
from datetime import datetime
from enum import Enum

from flask_login import UserMixin
from sqlalchemy import Enum as SAEnum
from werkzeug.security import generate_password_hash, check_password_hash

from app.extensions import db, login_manager


class Role(Enum):
    CUSTOMER = "customer"
    ADMIN = "admin"


class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(180), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(SAEnum(Role), default=Role.CUSTOMER, nullable=False, index=True)
    is_active_user = db.Column(db.Boolean, default=True, nullable=False)
    email_confirmed = db.Column(db.Boolean, default=False, nullable=False)
    phone = db.Column(db.String(40), nullable=True)
    address = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    last_login_at = db.Column(db.DateTime, nullable=True)
    failed_login_attempts = db.Column(db.Integer, default=0, nullable=False)
    locked_until = db.Column(db.DateTime, nullable=True)

    orders = db.relationship("Order", backref="user", lazy="dynamic")
    favorites = db.relationship("Favorite", backref="user", cascade="all, delete-orphan", lazy="dynamic")
    reviews = db.relationship("Review", backref="author", lazy="dynamic")
    tokens = db.relationship("Token", backref="user", cascade="all, delete-orphan", lazy="dynamic")

    # ----- password handling -----
    def set_password(self, raw: str) -> None:
        if len(raw) < 8:
            raise ValueError("Пароль должен содержать не менее 8 символов.")
        self.password_hash = generate_password_hash(raw, method="pbkdf2:sha256", salt_length=16)

    def check_password(self, raw: str) -> bool:
        if not self.password_hash:
            return False
        return check_password_hash(self.password_hash, raw)

    # ----- flask-login -----
    @property
    def is_active(self):
        return self.is_active_user

    @property
    def is_admin(self) -> bool:
        return self.role == Role.ADMIN

    def get_id(self):
        return str(self.id)

    def __repr__(self):
        return f"<User {self.email} ({self.role.value})>"


@login_manager.user_loader
def _load_user(user_id):
    try:
        return db.session.get(User, int(user_id))
    except (ValueError, TypeError):
        return None
