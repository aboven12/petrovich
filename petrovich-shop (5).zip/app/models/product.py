"""Product, Flavor, Category models."""
from datetime import datetime

from slugify import slugify as _slugify

from app.extensions import db


def slugify(value: str) -> str:
    """URL-safe slug, supports Cyrillic via python-slugify."""
    s = _slugify(value, lowercase=True, separator="-")
    return s or "item"


# Many-to-many: product <-> flavor (a product can have several flavors)
product_flavor = db.Table(
    "product_flavor",
    db.Column("product_id", db.Integer, db.ForeignKey("products.id"), primary_key=True),
    db.Column("flavor_id", db.Integer, db.ForeignKey("flavors.id"), primary_key=True),
)


class Flavor(db.Model):
    __tablename__ = "flavors"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), unique=True, nullable=False)
    slug = db.Column(db.String(80), unique=True, nullable=False, index=True)
    description = db.Column(db.Text, nullable=True)
    image = db.Column(db.String(255), nullable=True)
    color_hex = db.Column(db.String(9), default="#FF6B9D")
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    products = db.relationship("Product", secondary=product_flavor, backref="flavors")

    def __repr__(self):
        return f"<Flavor {self.name}>"


class Category(db.Model):
    __tablename__ = "categories"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), unique=True, nullable=False)
    slug = db.Column(db.String(80), unique=True, nullable=False, index=True)
    description = db.Column(db.Text, nullable=True)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    products = db.relationship("Product", backref="category", lazy="dynamic")

    def __repr__(self):
        return f"<Category {self.name}>"


class Product(db.Model):
    __tablename__ = "products"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(160), nullable=False)
    slug = db.Column(db.String(180), unique=True, nullable=False, index=True)
    description = db.Column(db.Text, nullable=True)
    composition = db.Column(db.Text, nullable=True)
    taste = db.Column(db.String(120), nullable=True)  # human-readable taste summary
    weight_g = db.Column(db.Integer, default=250, nullable=False)
    price = db.Column(db.Numeric(10, 2), nullable=False, default=0)
    old_price = db.Column(db.Numeric(10, 2), nullable=True)
    image = db.Column(db.String(255), nullable=True)
    shelf_life_days = db.Column(db.Integer, default=10, nullable=False)
    storage_conditions = db.Column(db.String(255), default="Хранить при температуре +18…+22°C в закрытой таре.")
    stock = db.Column(db.Integer, default=0, nullable=False)
    is_published = db.Column(db.Boolean, default=True, nullable=False, index=True)
    is_popular = db.Column(db.Boolean, default=False, nullable=False, index=True)
    is_new = db.Column(db.Boolean, default=False, nullable=False, index=True)
    rating = db.Column(db.Float, default=0.0, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    category_id = db.Column(db.Integer, db.ForeignKey("categories.id"), nullable=True, index=True)

    order_items = db.relationship("OrderItem", backref="product")
    favorites = db.relationship("Favorite", backref="product", cascade="all, delete-orphan", lazy="dynamic")
    reviews = db.relationship("Review", backref="product", lazy="dynamic")

    @property
    def in_stock(self) -> bool:
        return self.is_published and self.stock > 0

    @property
    def discount_percent(self) -> int:
        if self.old_price and self.old_price > self.price and self.old_price > 0:
            return int(round((1 - float(self.price) / float(self.old_price)) * 100))
        return 0

    def __repr__(self):
        return f"<Product {self.name} ₽{self.price}>"
