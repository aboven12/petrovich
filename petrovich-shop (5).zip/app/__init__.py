"""PETROVICH marmalade shop — application factory."""
import os

from flask import Flask
from config import config

from app.extensions import db, migrate, login_manager, csrf, limiter


def create_app(config_name=None):
    """Application factory."""
    if config_name is None:
        config_name = os.environ.get("FLASK_ENV", "default")

    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(config[config_name])

    # Ensure instance folder exists
    try:
        os.makedirs(app.instance_path, exist_ok=True)
    except OSError:
        pass

    # Ensure upload folder exists
    os.makedirs(os.path.join(app.root_path, "static", "images", "products"), exist_ok=True)

    # Init extensions
    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    csrf.init_app(app)
    limiter.init_app(app)

    # Security headers
    @app.after_request
    def set_security_headers(resp):
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
        resp.headers.setdefault("X-XSS-Protection", "1; mode=block")
        resp.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        resp.headers.setdefault("Permissions-Policy", "geolocation=(), microphone=(), camera=()")
        if not app.debug:
            resp.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
        return resp

    # Inject shop settings into every template
    @app.context_processor
    def inject_settings():
        try:
            from app.models.settings import ShopSettings
            return {"settings": ShopSettings.get()}
        except Exception:
            return {"settings": None}

    # Register blueprints
    from app.routes.main import main_bp
    from app.routes.auth import auth_bp
    from app.routes.shop import shop_bp
    from app.routes.account import account_bp
    from app.routes.admin import admin_bp
    from app.routes.api import api_bp

    app.register_blueprint(main_bp)
    app.register_blueprint(auth_bp, url_prefix="/auth")
    app.register_blueprint(shop_bp)
    app.register_blueprint(account_bp, url_prefix="/account")
    app.register_blueprint(admin_bp, url_prefix="/admin")
    app.register_blueprint(api_bp, url_prefix="/api")

    # Error handlers
    from app.errors import register_error_handlers
    register_error_handlers(app)

    # CLI commands
    from app.cli import register_cli
    register_cli(app)

    # Create tables on first run + auto-ensure admin (non-testing)
    with app.app_context():
        from app.models import User  # noqa: F401
        db.create_all()
        if not app.config.get("TESTING"):
            from app.cli import ensure_admin_exists
            ensure_admin_exists()

    return app
